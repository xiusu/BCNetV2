#!/usr/bin/env python
# -*- coding: utf-8 -*-
import argparse
import yaml
import os
import json

import nart_tools.kestrel.utils.scaffold as scaffold
import nart_tools.kestrel.utils.net_transform as transform

import nart_tools.proto.caffe_pb2 as caffe_pb2
import nart_tools.caffe.utils.graph as graph
import nart_tools.caffe.convert as convert
import nart_tools.caffe.count as count


def get_spatial(node):
    tmp_node = node
    _, _, infer_shape = count.inferNet(net)
    while True:
        if tmp_node.content.type == 'Pooling':
            spatial = infer_shape[tmp_node.prev[0].content.top[0]][2]
            break
        tmp_node = tmp_node.prev[0]
    return spatial


def remove_branch(net, node):
    tmp = node
    while True:
        print('remove useless layer: {}'.format(tmp.content.name))
        net.layer.remove(tmp.content)
        if len(tmp.prev[0].succ) > 1:
            break
        tmp = tmp.prev[0]
    return net


def add_layer(net, net_graph, node, input_h, input_w, num_kpts):
    _ = transform.add_sigmoid(net, net_graph, node.content, 'visibility', insert=False)
    tmp = node
    while tmp.content.type != 'Convolution':
        tmp = tmp.prev[0]
    tmp = transform.add_slice(net, net_graph, tmp.content, 'fg', slice_point=num_kpts, axis=1, insert=False)
    tmp = transform.add_sigmoid(net, net_graph, tmp, 'fg', insert=False)
    _ = transform.add_heatmap2coord(net, net_graph, tmp, 'fg', input_h, input_w, coord_reposition=True, insert=False)

    return net


def generate_parameter(path, packname, max_batch_size, net_info, cfg_params):
    param = dict()
    param['model_files'] = dict()
    net = dict()
    net['net'] = packname
    net['backend'] = net_info['backend']
    net['max_batch_size'] = max_batch_size
    net['input'] = {'data': net_info['data']}
    net['output'] = {'point': net_info['point'], 'score': net_info['score']}
    param['model_files']['net'] = net
    param['input_h'] = cfg_params['structure']['input_h']
    param['input_w'] = cfg_params['structure']['input_w']
    param['padding'] = [(cfg_params['test']['box_scale'] - 1) / 2] * 4
    param['square'] = cfg_params['common']['crop_square']
    param['pixel_means'] = [i * cfg_params['common']['img_norm_factor'] for i in cfg_params['common']['means']]
    param['pixel_stds'] = [i * cfg_params['common']['img_norm_factor'] for i in cfg_params['common']['stds']]
    param['is_rgb'] = True
    scaffold.generate_json_file(os.path.join(path, 'parameters.json'), param)


def process_net(net, input_h, input_w, num_kpts):
    net_graph = graph.gen_graph(net)

    # find branch with max_spatial
    idx = -1
    max_spatial = -1
    for i, node in enumerate(net_graph.leaf):
        spatial = get_spatial(node)
        if spatial > max_spatial:
            idx = i
            max_spatial = spatial

    # update net structure
    for i, node in enumerate(net_graph.leaf):
        if i == idx:
            net = add_layer(net, net_graph, node, input_h, input_w, num_kpts)
        else:
            net = remove_branch(net, node)


def generate(net, path, name, serialize, max_batch_size, cfg_params, version):
    packname = 'model'
    # generate model and save to path
    model_path = scaffold.generate_model(net, path, packname)

    net_info = dict()
    # serialize model
    if serialize:
        packname = 'engine.bin'
        engine_path =os.path.join(path, packname)
        scaffold.serialize(model_path, max_batch_size, engine_path)
        net_info['backend'] = 'kestrel_mixnet'
    else:
        net_info['backend'] = 'kestrel_caffe'

    # generate meta
    scaffold.generate_meta(path, args.name, 'raven', version)

    # generate parameter
    net_graph = graph.gen_graph(net)
    assert len(net_graph.root) == 1 and len(net_graph.root[0].content.bottom) == 1
    net_info['data'] = net_graph.root[0].content.bottom[0]
    assert len(net_graph.leaf) == 2
    for node in net_graph.leaf:
        assert len(node.content.top) == 1
        if node.content.type == 'Sigmoid':
            net_info['score'] = node.content.top[0]
        else:
            net_info['point'] = node.content.top[0]
    generate_parameter(path, packname, max_batch_size, net_info, cfg_params)

    # compress and save
    scaffold.compress_model(path, [packname], name, version)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='convert caffe and param to kestrel raven model')
    parser.add_argument('prototxt', help='path to the prototxt')
    parser.add_argument('model', help='path to the model.bin')
    parser.add_argument('-v', '--version', type=str, default='1.0.0', help='version to meta.conf')
    parser.add_argument('-c', '--config', type=str, required=True, help='train config')
    parser.add_argument('-n', '--name', type=str, default='None', help='compressed model name')
    parser.add_argument('-p', '--path', type=str, default='.', help='path to save model')
    parser.add_argument('-s', '--serialize', action="store_true", help='serialize fp32 model')
    parser.add_argument('-b', '--max_batch_size', type=int, default=32, help='max_batch_size')

    args = parser.parse_args()

    # check meta version format
    version = scaffold.check_version_format(args.version)

    # load train config
    with open(args.config) as f:
        cfg_params = yaml.load(f)
    assert cfg_params['common']['keep_aspect_ratio'] == False
    assert cfg_params['common']['bg'] == True

    # get net
    net, withBinFile  = graph.readNetStructure(args.prototxt,
                                         args.model)

    # merge bn
    net = scaffold.merge_bn(net)

    # parse and process net: remove useless layer and add neccesary layer(slice,heatmap2coord/sigmoid)
    process_net(net, cfg_params['structure']['input_h'], cfg_params['structure']['input_w'], cfg_params['structure'].get('num_kpts', 14))

    # generate model (serialize), meta and parameter
    generate(net, args.path, args.name, args.serialize, args.max_batch_size, cfg_params, version)

