from .layer import Layer

class Concat(Layer):

    def set_top(self):
        self.params.top.extend(self.node.output)

    def set_bottom(self):
        self.params.bottom.extend(self.node.input)

    def set_param(self):
        attributes = dict(zip([attr.name for attr in self.node.attribute], self.node.attribute))
        self.params.concat_param.axis = attributes['axis'].i 

    def set_blobshape(self):
        top_shape = self.network.blobshape[self.params.bottom[0]][:]
        top_shape[self.params.concat_param.axis] = 0
        for bottom in self.params.bottom:
            top_shape[self.params.concat_param.axis] += \
                    self.network.blobshape[bottom][self.params.concat_param.axis]
        self.network.blobshape[self.params.top[0]] = top_shape 