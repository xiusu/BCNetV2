import torch
from torch.autograd import Function

class FlipForward(Function):

    @staticmethod
    def forward(ctx, input, dims):
        return torch.Tensor.ori_flip(input, dims)

    @staticmethod
    def symbolic(g, input, dims):
        return g.op("Flip", input, dims_i=dims)

def forward(input, dims):
    return FlipForward.apply(input, dims)