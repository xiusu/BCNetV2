from .layer import Layer

class Scale(Layer):

    def set_top(self):
        self.params.top.extend(self.node.output)

    def set_bottom(self):
        self.params.bottom.extend(self.node.input[0:1])

    def set_param(self):
        self.params.scale_param.bias_term = True
        scale_blob = self.network.blobs[self.node.input[1]]
        self.params.blobs.extend([Layer.array_to_blobproto(scale_blob)])
        bias_blob = self.network.blobs[self.node.input[2]]
        self.params.blobs.extend([Layer.array_to_blobproto(bias_blob)])

    def set_blobshape(self):
        self.network.blobshape[self.params.top[0]] = self.network.blobshape[self.params.bottom[0]]