import torch
from torch.nn import Module
import warnings

_flatten = torch._C._jit_flatten
_unflatten = torch._C._jit_unflatten

def _iter_filter(condition, allow_unknown=False, condition_msg=None):
    def _iter(obj):
        if condition(obj):
            yield obj
        elif obj is None:
            return
        elif isinstance(obj, (list, tuple)):
            for o in obj:
                for var in _iter(o):
                    yield var
        elif isinstance(obj, dict):
            for k, v in obj.items():
                if k == 'image':
                    yield v
        elif allow_unknown:
            yield obj
        else:
            warnings.warn("Skipping input - Auto nesting doesn't know how to process "
                             "an input object of type " + torch.typename(obj) +
                             (". Accepted types: " + condition_msg +
                              ", or lists/tuples of them, or a dict where 'image' contains the tensor."
                              if condition_msg else ""))
            return

    return _iter

def _unique_state_dict(module, keep_vars=False):
    state_dict = module.state_dict(keep_vars=keep_vars)
    filtered_dict = type(state_dict)()
    seen_ids = set()
    for k, v in state_dict.items():
        if id(v) in seen_ids:
            continue
        seen_ids.add(id(v))
        filtered_dict[k] = v
    return filtered_dict

class LegacyTracedModule(Module):
    def __init__(self, inner, nderivs=0):
        super(LegacyTracedModule, self).__init__()
        # inner may be a Module, or it may be an arbitrary callable
        # If it's a Module, we get its parameters automatically, which lets
        # us avoid a special casing functions versus modules.
        self.inner = inner
        self.nderivs = nderivs

    def forward(self, *args):
        dict_input = isinstance(args[0], dict)
        if dict_input:
            in_vars, in_desc = _flatten((args[0]['image'], ))
        else:
            in_vars, in_desc = _flatten(args)
        # NOTE: use full state, because we need it for BatchNorm export
        # This differs from the compiler path, which doesn't support it at the moment.
        module_state = list(_unique_state_dict(self, keep_vars=True).values())
        trace, all_trace_inputs = torch._C._tracer_enter(in_vars + module_state, self.nderivs)
        torch.jit._tracing = True
        trace_inputs = _unflatten(all_trace_inputs[:len(in_vars)], in_desc)
        if dict_input:
            trace_inputs = args[0]
            if len(trace_inputs['image']) == 1:
                trace_inputs['image'] = trace_inputs['image'][0]
            out = self.inner(trace_inputs)
        else:
            out = self.inner(*trace_inputs)
        out_vars, _ = _flatten(out)
        torch.jit._tracing = False
        torch._C._tracer_exit(out_vars)
        return trace, out
