#!/usr/bin/python
#-*- coding:utf-8 -*-
import nart_tools.proto.caffe_pb2 as caffe_pb2
import nart_tools.caffe.utils.graph as graph
import argparse
import copy
import os
import json

from nart_tools.caffe.utils.graph import readNetStructure
from nart_tools.caffe.convert import generateModel

def rmLayerWithName(net, nodes):
    for i in nodes:
        for index in range(len(net.layer))[::-1]:
            j = net.layer[index]
            if i == j.name:
                print("remove " + i)
                assert(len(j.top) == 1)
                assert(len(j.bottom) == 1)
                top = j.top[0]
                bottom = j.bottom[0]
                flag = top
                if top.isdigit():
                    flag = bottom
                for x in range(len(net.layer))[::-1]:
                    l = net.layer[x]
                    if l.name == j.name:
                        continue
                    for ind in range(len(l.bottom)):
                        if l.bottom[ind] == top:
                            net.layer[x].bottom[ind] = flag
                    for ind in range(len(l.top)):
                        if l.top[ind] == bottom:
                            net.layer[x].top[ind] = flag

                net.layer.remove(j)
    return net

def generateModel(net, path, mname):
    if path[-1] ==  "/":
        path = path[:-1]
    path += "/" + mname
    os.system("mkdir -p " + path)
    with open(path + "/model.bin", "wb") as f:
        f.write(net.SerializeToString())
    for layer in net.layer:
        layer.ClearField("blobs")
    with open(path + "/rel.prototxt", "w") as f:
        f.write(str(net))

def dealWithCorrelation(net):
    for ind in range(len(net.layer)):
        layer = net.layer[ind]
        net.layer[ind].ClearField("correlation_param")
    return net

def rmUnuseReshape(net):
    rmList = []
    for layer in net.layer:
        if layer.type == "Correlation":
            for j in net.layer:
                if j.type == "Reshape":
                    for x in j.top:
                        if x in layer.bottom and j.name not in rmList:
                            rmList.append(j.name)
                    for x in j.bottom:
                        if x in layer.top and j.name not in rmList:
                            rmList.append(j.name)
    net = rmLayerWithName(net, rmList)
    net = dealWithCorrelation(net)
    return net

def rmBN(net):
    from nart_tools.caffe.convert import mergeLayers
    net = mergeLayers(net,
            handleBlob = True,
            batchnorm = True,
            bn = True,
            scale = True,
            bns = True,
            BNs = True,
            verbose = True)
    return net

def generateMetaFile(path, version = [0,0,0]):
    if args.type == 'kestrel':
        temp = """
version {{
    major: {major}
    minor: {minor}
    patch: {patch}
    train_date: "{date}"
}}
model_name: "KM_Hermes"
model_type: "hermes"
description: "Siamese RPN Regressor Tracker, kernel/det, caffe"
"""
    else:
        temp = """
version {{
    major: {major}
    minor: {minor}
    patch: {patch}
    train_date: "{date}"
}}
model_name: "M_Siamese_RPN"
model_type: "sot_tracker"
description: "Siamese Regressor Tracker version {major}.{minor}.{patch}"
model_files {{
  version {{
    major: {major}
    minor: {minor}
    patch: {patch}
    train_date: "{date}"
  }}
  filenames: "model"
  model_type: Caffe
  name: "model"
}}
model_files {{
  version {{
    major: {major}
    minor: {minor}
    patch: {patch}
    train_date: "{date}"
  }}
  filenames: "det"
  model_type: Caffe
  name: "det"
}}
model_files {{
  version {{
    major: {major}
    minor: {minor}
    patch: {patch}
    train_date: "{date}"
  }}
  filenames: "kernel"
  model_type: Caffe
  name: "kernel"
}}
model_files {{
  version {{
    major: {major}
    minor: {minor}
    patch: {patch}
    train_date: "{date}"
  }}
  filenames: "parameters.json"
  model_type: Custom
  name: "parameters"
}}
"""
    import datetime
    date = datetime.date.today().strftime("%Y%m%d")
    s = temp.format(major=version[0], minor=version[1], patch=version[2],
                date=date)

    with open(path + "/meta.conf", "w") as f:
        f.write(s)

    if args.type == 'kestrel':
        temp = {
                "model_name": "KM_Hermes",
                "model_type": "hermes",
                "version": {
                    "major": version[0],
                    "minor": version[1],
                    "patch": version[2],
                    "train_date": date
                    },
                "properties": {"description": ""},
                "configuration": {}
                }
        with open(path + "/meta.json", "w") as f:
            json.dump(temp, f, indent=4)
    return


def toppl(path):
    cmd = "cd " + path + ";"
    cmd += "sed -i 's-Correlation\"-Correlation2d\"-' */rel.prototxt;"
    cmd += "sed -i s-ShuffleChannel-ChannelShuffle-g */rel.prototxt;"
    cmd += "sed -i s-shuffle_channel_param-channel_shuffle_param-g */rel.prototxt"
    print(cmd)
    os.system(cmd)


def tarAllToPackage(path, name):
    files = [
        "det",
        "kernel",
        "model",
        "meta.conf",
        "parameters.json"
    ]
    if args.type == 'kestrel':
        files.append("meta.json")
    cmd = "cd " + path + " && "
    cmd += "tar -cvf %s %s" % (name, " ".join(files))
    print(cmd)
    os.system(cmd)
    return

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description = "convert caffe and param to kestrel model")
    parser.add_argument("model", help = "path to the det/kernel model, with det.prototxt/caffemodel and kernel.prototxt/caffemodel")
    parser.add_argument("-v", "--version", type = str, default = "1.0.0", help = "version to meta.conf")
    parser.add_argument("-t", "--type", type = str, default = "kestrel", choices = ["kestrel", "sdk_sense_go"], help = "convert to")

    args = parser.parse_args()

    net, withBinFile = readNetStructure(args.model + "/det.prototxt", args.model + "/det.caffemodel")
    net = rmUnuseReshape(net)
    net = rmBN(net)
    generateModel(net, args.model, "det")

    net, withBinFile = readNetStructure(args.model + "/kernel.prototxt", args.model + "/kernel.caffemodel")
    net = rmUnuseReshape(net)
    net = rmBN(net)
    generateModel(net, args.model, "kernel")

    net, withBinFile = readNetStructure(args.model + "/model.prototxt", args.model + "/model.caffemodel")
    net = rmUnuseReshape(net)
    net = rmBN(net)
    generateModel(net, args.model, "model")
    try:
        if len(args.version.split(".")) == 3:
            version = [int(i) for i in args.version.split(".")]
        else:
            version = [1, 0, 0]
    except:
        version = [1, 0, 0]

    generateMetaFile(args.model, version)
    if args.type == 'sdk_sense_go':
        toppl(args.model)
    tarAllToPackage(args.model, "KM_Hermes_%d.%d.%d.tar" % (version[0], version[1], version[2]))

