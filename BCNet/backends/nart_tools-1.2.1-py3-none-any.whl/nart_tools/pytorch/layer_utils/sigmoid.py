from .layer import Layer

class Sigmoid(Layer):

    def set_top(self):
        self.params.top.extend(self.node.output)

    def set_bottom(self):
        self.params.bottom.extend(self.node.input)

    def set_param(self):
        pass

    def set_blobshape(self):
        self.network.blobshape[self.params.top[0]] = self.network.blobshape[self.params.bottom[0]]