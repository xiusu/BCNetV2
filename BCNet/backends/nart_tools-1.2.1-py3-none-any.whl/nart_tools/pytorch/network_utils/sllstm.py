def merge_lstm_nodes(model):
    '''
    Version specific for 1.0.x
    A sequence of lstm nodes with the same input blob 
    corresponds to one or a sequence of holistic SLLSTM layer in caffe.
    This method merges the nodes into one node corresponding
    to that layer.
    ''' 
    nodes = model.graph.node[:]
    del model.graph.node[:]

    idx = 0
    while idx < len(nodes):
        node = nodes[idx]
        if node.op_type != 'LSTM':
            model.graph.node.extend([node])
            idx += 1
            continue
        prev_lstm_node = node
        while idx < len(nodes):
            idx += 1
            if idx >= len(nodes):
                model.graph.node.extend([prev_lstm_node])
                break
            node = nodes[idx]
            if node.op_type != 'LSTM':
                model.graph.node.extend([prev_lstm_node])
                break
            if node.input == prev_lstm_node.input: 
                continue
            else:
                model.graph.node.extend([prev_lstm_node])
                prev_lstm_node = node

            