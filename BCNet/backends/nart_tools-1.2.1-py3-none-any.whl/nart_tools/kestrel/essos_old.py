#!/usr/bin/python
#-*- coding:utf-8 -*-
import nart_tools.proto.caffe_pb2 as caffe_pb2
import nart_tools.caffe.utils.graph as graph
import argparse
import copy
import os
import json

from nart_tools.caffe.utils.graph import readNetStructure
from nart_tools.kestrel.hermes import rmBN
from nart_tools.kestrel.hermes import generateModel
import nart_tools.caffe.count as cm
from nart_tools.kestrel.utils.anchor_helper import get_anchors_over_grid

def toNear2Pow(x):
    import math
    return int(math.pow(2, round(math.log(x, 2))))

def get_anchors_pytorch(ratios, scales, stride):
    """
    Generate anchor (reference) windows by enumerating aspect ratios X
    scales wrt a reference (0, 0, stride-1, stride-1) window.
    """
    import numpy as np
    scales = np.array(scales) * stride
    scales, ratios = np.meshgrid(scales, ratios)
    sqrt_ratios = np.sqrt(ratios)
    ws = (scales / sqrt_ratios).reshape(-1,1)
    hs = (scales * sqrt_ratios).reshape(-1,1)
    x = np.round(ws / 2.0)
    y = np.round(hs / 2.0)
    return np.hstack([-x,-y,x,y]) + stride / 2

def getNetworkDetail(net):
    netGraph = graph.gen_graph(net)
    blobDict = cm.inferNet(net)[2]
    findSigmoid = False
    findSoftmax = False
    for i in net.layer:
        if i.type == "Sigmoid":
            findSigmoid = True
        if i.type == "Softmax":
            findSoftmax = True
    assert(not (findSigmoid and findSoftmax))
    assert(findSigmoid or findSoftmax)
    detail = {}
    detail["findSigmoid"] = findSigmoid
    detail["findSoftmax"] = findSoftmax
    detail["output"] = [x for y in [i.content.top for i in netGraph.leaf] for x in y]
    detail["input"] = [x for y in [i.content.bottom for i in netGraph.root] for x in y]
    detail["output"].sort(key = lambda x: blobDict[x][1])
    detail["output"].sort(key = lambda x: blobDict[x][3], reverse = True)
    x = []
    for i in range(len(detail["output"]) // 2):
        x.append([detail["output"][2 * i], detail["output"][2 * i + 1]])
    detail["output"] = x
    inp_shape = blobDict[detail["input"][0]]
    stride = []
    for i in detail["output"]:
        stride.append(toNear2Pow(inp_shape[2] / blobDict[i[0]][2]))
    detail["stride"] = stride
    return detail

def dealWithHWConf(netDetail, path, means = [128], stds = [1]):
    with open(path) as f:
        inp = json.load(f)
    oup = {}

    net = {}
    net["net"] = "rpn"
    net["backend"] = "kestrel_mixnet"
    net["max_batch_size"] = 15
    net["input"] = {}
    net["input"]["data"] =  netDetail["input"][0]
    net["output"] = {}
    oup["rpn_blobs"] = []
    ind = 1
    for i in netDetail["output"]:
        net["output"]["score" + str(ind)] = i[0]
        net["output"]["bbox" + str(ind)] = i[1]
        oup["rpn_blobs"].append(["score" + str(ind), "bbox" + str(ind)])
        ind += 1

    oup["model_files"] = {}
    oup["model_files"]["net"] =  net
    oup["nms_thresh"] = inp["rpn"]["test"]["nms_iou_thresh"]
    oup["long_scale"] = inp["shared"]["max_size"]
    oup["short_scale"] = inp["shared"]["scales"][0]
    oup["pre_top_k"] = inp["rpn"]["test"]["pre_nms_top_n"]
    oup["aft_top_k"] = inp["rpn"]["test"]["post_nms_top_n"]
    oup["anchor_scales"] = inp["rpn"]["anchor_scales"]
    oup["anchor_ratios"] = inp["rpn"]["anchor_ratios"]
    oup["pixel_means"] = means
    oup["pixel_stds"] = stds
    oup["rpn_stride"] = netDetail["stride"]
    oup["rpn_top_n"] = [1000] * len(netDetail["stride"])
    oup["with_background_class"] = netDetail["findSoftmax"]
    oup["class"] = []
    for i in range(len(inp["shared"]["class_names"])):
        x = {}
        x["id"] = 124600 + (i + 1)
        x["label"] = inp["shared"]["class_names"][i]
        x["thresh"] = 0.3
        x["filter_w"] = 8
        x["filter_h"] = 8
        oup["class"].append(x)
    oup["anchors"] = []
    for i in oup["rpn_stride"]:
        anchors = get_anchors_over_grid(oup["anchor_ratios"], oup["anchor_scales"], i).tolist()
        oup["anchors"].append(anchors)
    return oup

def dealWithStandConf(netDetail, path, means = [128], stds = [1]):
    with open(path) as f:
        inp = json.load(f)
    oup = {}

    net = {}
    net["net"] = "rpn"
    net["backend"] = "kestrel_mixnet"
    net["max_batch_size"] = 15
    net["input"] = {}
    net["input"]["data"] =  netDetail["input"][0]
    net["output"] = {}
    oup["rpn_blobs"] = []
    ind = 1
    for i in netDetail["output"]:
        net["output"]["score" + str(ind)] = i[0]
        net["output"]["bbox" + str(ind)] = i[1]
        oup["rpn_blobs"].append(["score" + str(ind), "bbox" + str(ind)])
        ind += 1
    oup["model_files"] = {}
    oup["model_files"]["net"] =  net
    oup["nms_thresh"] = inp["test_rpn_proposal_cfg"]["nms_iou_thresh"]
    oup["long_scale"] = inp["shared"]["max_size"]
    oup["short_scale"] = inp["shared"]["scales"][-1]
    if "pre_nms_top_n" in inp["test_rpn_proposal_cfg"]:
        oup["pre_top_k"] = inp["test_rpn_proposal_cfg"]["pre_nms_top_n"]
    else:
        oup["pre_top_k"] = inp["test_rpn_proposal_cfg"]["top_n_per_level"]
    if "post_nms_top_n" in inp["test_rpn_proposal_cfg"]:
        oup["aft_top_k"] = inp["test_rpn_proposal_cfg"]["post_nms_top_n"]
    else:
        oup["aft_top_k"] = inp["test_rpn_proposal_cfg"]["top_n"]

    oup["anchor_scales"] = inp["shared"]["anchor_scales"]
    oup["anchor_ratios"] = inp["shared"]["anchor_ratios"]
    oup["pixel_means"] = means
    oup["pixel_stds"] = stds
    oup["rpn_stride"] = netDetail["stride"]
    oup["rpn_top_n"] = [1000] * len(netDetail["stride"])
    oup["with_background_class"] = netDetail["findSoftmax"]
    oup["class"] = []
    for i in range(0, len(inp["shared"]["class_names"])):
        x = {}
        x["id"] = 124600 + (i + 1)
        x["label"] = inp["shared"]["class_names"][i]
        x["thresh"] = 0.3
        x["filter_w"] = 8
        x["filter_h"] = 8
        oup["class"].append(x)
    oup["anchors"] = []
    for i in oup["rpn_stride"]:
        anchors = get_anchors_over_grid(oup["anchor_ratios"], oup["anchor_scales"], i).tolist()
        oup["anchors"].append(anchors)
    return oup

def doMetaFile(path, param, version, name):
    import datetime
    metajson = {}
    metajson["model_name"] = "KM_Essos"
    metajson["model_type"] = "essos"
    metajson["description"] = ""
    metajson["version"] = {}
    metajson["version"]["major"] = version[0]
    metajson["version"]["minor"] = version[1]
    metajson["version"]["patch"] = version[2]
    metajson["version"]["train_date"] = datetime.date.today().strftime("%Y%m%d")
    metajson["properties"] = {"description": ""}
    metajson["configuration"] = {}
    metajson["configuration"]["class"] = param["class"]
    s = json.dumps(metajson, indent = 4)
    with open(path + "/meta.json", "w") as f:
        f.write(s)
    temp = """version {
  major: %d
  minor: %d
  patch: %d
  train_date: "%s"
}
model_name: "KM_Essos_%s"
model_type: "essos"
description: ""
"""
    import datetime
    s = temp % (version[0], version[1], version[2], datetime.date.today().strftime("%Y%m%d"), name)
    with open(path + "/meta.conf", "w") as f:
        f.write(s)
    return

def tarAllToPackage(path, name):
    files = [
        "rpn",
        "meta.conf",
        "meta.json",
        "parameters.json"
    ]
    cmd = "cd " + path + " && "
    cmd += "tar -cvf %s %s" % (name, " ".join(files))
    print(cmd)
    os.system(cmd)
    return

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description = "convert caffe and param to kestrel model")
    parser.add_argument("model", help = "path to the model, with prototxt/caffemodel")
    parser.add_argument("-p" , "--prefix", type = str, required = True, help = "model prefix")
    parser.add_argument("-v", "--version", type = str, default = "1.0.0", help = "version to meta.conf")
    parser.add_argument("-m", "--means", type = str, default = "123.675,116.28,103.53", help = "image normalize mean, on 0~255 input, with ',' split")
    parser.add_argument("-s", "--stds", type = str, default = "58.395,57.12,57.375", help = "image normalize std, on 0~255 input,  with ',' split")
    parser.add_argument("-n", "--name", type = str, default = "None", help = "model name that you give")

    args = parser.parse_args()

    net, withBinFile  = readNetStructure(args.model + "/" + args.prefix + ".prototxt",
                                         args.model + "/" + args.prefix + ".caffemodel")
    net = rmBN(net)
    generateModel(net, args.model, "rpn")
    try:
        if len(args.version.split(".")) == 3:
            version = [int(i) for i in args.version.split(".")]
        else:
            version = [1, 0, 0]
    except:
        version = [1, 0, 0]

    detail = getNetworkDetail(net)

    with open(args.model + "/config.json") as f:
        inp = json.load(f)
    if "test_rpn_proposal_cfg" not in inp:
        param = dealWithHWConf(detail, args.model + "/config.json",    [float(i) for i in args.means.split(",")], [float(i) for i in args.stds.split(",")])
    else:
        param = dealWithStandConf(detail, args.model + "/config.json", [float(i) for i in args.means.split(",")], [float(i) for i in args.stds.split(",")])

    s = json.dumps(param, indent = 4)
    with open(args.model + "/parameters.json", "w") as f:
        f.write(s)
    doMetaFile(args.model, param, version, args.name)
    tarAllToPackage(args.model, "KM_Essos_%s_%d.%d.%d.tar" % (args.name ,version[0], version[1], version[2]))
