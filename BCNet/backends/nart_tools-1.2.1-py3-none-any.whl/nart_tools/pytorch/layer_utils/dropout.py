from .layer import Layer

class Dropout(Layer):

    def set_top(self):
        self.params.top.extend(self.node.output[0:1])

    def set_bottom(self):
        self.params.bottom.extend(self.node.input)

    def set_param(self):
        attributes = dict(zip([attr.name for attr in self.node.attribute], self.node.attribute))
        self.params.dropout_param.dropout_ratio = attributes['ratio'].f

    def set_blobshape(self):
        self.network.blobshape[self.params.top[0]] = self.network.blobshape[self.params.bottom[0]]