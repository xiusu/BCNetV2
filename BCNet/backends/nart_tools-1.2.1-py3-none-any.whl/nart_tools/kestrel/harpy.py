#!/usr/bin/env python
# -*- coding: utf-8 -*-
import argparse
import yaml
import json
import os

import nart_tools.kestrel.utils.pod as pod
import nart_tools.kestrel.utils.scaffold as scaffold

import nart_tools.caffe.utils.graph as graph
import nart_tools.caffe.count as count
import nart_tools.proto.caffe_pb2 as caffe_pb2


def get_subnet(net, root):
    bottom = root.content.bottom[0]
    nodes = [root]
    subnet = []
    while len(nodes) > 0:
        node = nodes.pop()
        if node.content in net.layer:
            layer = caffe_pb2.LayerParameter()
            layer.CopyFrom(node.content)
            net.layer.remove(node.content)
            subnet.append(layer)
        for succ in node.succ:
            insert = True
            for prev in succ.prev:
                if prev.content in net.layer:
                    insert = False
            if insert:
                nodes.append(succ)
    return bottom, subnet


def split_net(net, anchor_num, cls_num, bbox_head_type):
    net_graph = graph.gen_graph(net)
    net_info = dict()
    rpn_info = dict()
    det_info = dict()
    roi_blob_name = 'roi' # specify roi input name

    # parse raw net input: 2 dummy input and 1 rpn input
    det_net_root = [] # save two det net Convolution root layer
    for node in net_graph.root:
        if node.content.type == 'DummyData':
            det_info['roi'] = roi_blob_name
            node.succ[0].content.bottom.remove(node.content.top[0])
            node.succ[0].content.bottom.append(roi_blob_name)
            if 'RFCN' in bbox_head_type:
                for brother in node.succ[0].prev:
                    if brother.content.type != 'DummyData':
                        det_net_root.append(brother)
            else:
                det_net_root.append(node.succ[0])
            net.layer.remove(node.content)
        else:
            rpn_info['data'] = node.content.bottom[0]

    # construct det net
    det_net = caffe_pb2.NetParameter()
    det_net.input.append(roi_blob_name)
    det_net.input_dim.extend([1, 5, 1, 1])

    subnet_bottom = set()
    assert len(det_net_root) == 2 if 'RFCN' in bbox_head_type else 1
    for root in det_net_root:
        bottom, subnet = get_subnet(net, root)
        subnet_bottom.add(bottom)
        det_net.layer.extend(subnet)

    # add feature input for det net
    assert len(subnet_bottom) == 1
    feature_blob_name = subnet_bottom.pop()
    det_net.input.append(feature_blob_name)
    rpn_info['feature'] = feature_blob_name

    # processed net -> rpn_net
    rpn_net = net

    # process reshape
    pod.process_reshape(rpn_net, anchor_num, 2, anchor_precede=False)
    pod.process_reshape(det_net, 1, cls_num, anchor_precede=False)

    # inference rpn net info
    _, _, rpn_shape = count.inferNet(rpn_net)
    det_net.input_dim.extend(rpn_shape[feature_blob_name])
    rpn_graph = graph.gen_graph(rpn_net)
    assert len(rpn_graph.leaf) == 3 if 'RFCN' in bbox_head_type else 2
    for leaf in rpn_graph.leaf:
        if feature_blob_name != leaf.content.top[0]:
            shape = rpn_shape[leaf.content.top[0]]
            if shape[1] == anchor_num * 4:
                rpn_info['bbox'] = leaf.content.top[0]
            else:
                rpn_info['score'] = leaf.content.top[0]

    # inference det net info
    _, _, det_shape = count.inferNet(det_net)
    det_graph = graph.gen_graph(det_net)
    assert len(det_graph.leaf) == 2
    for leaf in det_graph.leaf:
        shape = det_shape[leaf.content.top[0]]
        if shape[1] == cls_num:
            det_info['score'] = leaf.content.top[0]
        else:
            det_info['bbox'] = leaf.content.top[0]

    net_info['rpn'] = rpn_info
    net_info['det'] = det_info
    return rpn_net, det_net, net_info

def process_net(prototxt, model, anchor_num, cls_num, input_h, input_w, bbox_head_type):
    # get net
    net, withBinFile  = graph.readNetStructure(args.prototxt,
                                         args.model)

    # update input dim
    scaffold.update_input_dim(net, 0, [1, 3, input_h, input_w])

    # process reshape
    # pod.process_reshape(net, anchor_num, cls_num, anchor_precede=False)

    # parse and update
    # split rpn & det and get input/output info
    rpn_net, det_net , net_info = split_net(net, anchor_num, cls_num, bbox_head_type)

    # merge bn
    rpn_net = scaffold.merge_bn(rpn_net)
    det_net = scaffold.merge_bn(det_net)

    return rpn_net, det_net, net_info

def generate_config(train_config, kestrel_config, anchor_config):
    with open(train_config) as f:
        train_cfg = yaml.load(f)

    kestrel_param = dict()

    # parse config parameters needed

    # net param
    assert 'net' in train_cfg, 'config file incomplete: lack net infomation'
    net_param = pod.parse_net_param(train_cfg['net'])
    assert 'backbone' in net_param and 'neck' not in net_param and 'roi_head' in net_param and 'bbox_head' in net_param
    kestrel_net_param = dict()
    assert len(net_param['backbone']['out_strides']) == 1
    kestrel_net_param['detection_stride'] = net_param['backbone']['out_strides'][0]
    kestrel_net_param['anchor_ratios'] = net_param['roi_head']['anchor_ratios']
    kestrel_net_param['anchor_scales'] = net_param['roi_head']['anchor_scales']
    kestrel_net_param['anchors'] = pod.generate_anchor(
        anchor_config, kestrel_net_param['anchor_ratios'],
        kestrel_net_param['anchor_scales'], [kestrel_net_param['detection_stride']])[0]
    kestrel_net_param['pre_top_k'] = net_param['roi_head']['pre_nms_top_n']
    kestrel_net_param['aft_top_k'] = net_param['roi_head']['post_nms_top_n']
    kestrel_net_param['rpn_nms_thresh'] = net_param['roi_head']['nms_iou_thresh']
    kestrel_net_param['det_nms_thresh'] = net_param['bbox_head']['nms_iou_thresh']
    kestrel_param.update(kestrel_net_param)

    # dataset param
    assert 'dataset' in train_cfg, 'config file incomplete: lack dataset'
    train_cfg['dataset']['class_names'] = train_cfg['dataset']['class_names'][1:]

    if kestrel_config == '':
        kestrel_cfg = dict()
        kestrel_cfg['class'] = {name:{} for name in train_cfg['dataset']['class_names']}
    else:
        with open(kestrel_config) as f:
            kestrel_cfg = yaml.load(f)
    dataset_param = pod.parse_dataset_param(
            train_cfg['dataset'], kestrel_cfg['class'],
            'confidence_thresh', net_param['bbox_head']['bbox_score_thresh'])
    kestrel_param.update(dataset_param)
    kestrel_param['rgb_flag'] = True

    names = [net['name'] for net in train_cfg['net']]
    bbox_head_type = train_cfg['net'][names.index('bbox_head')]['type']

    return kestrel_param, bbox_head_type


def generate_common_param(net_info, max_batch_size, aft_top_k):
    common_param = dict()
    rpn_param = dict()
    det_param = dict()
    rpn_param['net'] = net_info['rpn']['packname']
    rpn_param['backend'] = net_info['rpn']['backend']
    rpn_param['max_batch_size'] = max_batch_size
    rpn_param['input'] = {'data': net_info['rpn']['data']}
    rpn_param['output'] = {'bbox': net_info['rpn']['bbox'], 'score': net_info['rpn']['score']}
    rpn_param['marked_output'] = {'shared_rpn_layer': net_info['rpn']['feature']}

    det_param['net'] = net_info['det']['packname']
    det_param['backend'] = net_info['det']['backend']
    det_param['max_batch_size'] = max_batch_size * aft_top_k
    det_param['input'] = {'feature': net_info['rpn']['feature'], 'roi': net_info['det']['roi']}
    det_param['output'] = {'bbox': net_info['det']['bbox'], 'score': net_info['det']['score']}

    common_param['rpn_net'] = rpn_param
    common_param['det_net'] = det_param
    return common_param


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description = 'convert model and config from pytorch to kestrel harpy')
    parser.add_argument('prototxt', help='path to the prototxt', action=None)
    parser.add_argument('model', help='path to the model.bin')
    parser.add_argument('-v', '--version', type=str, default='1.0.0', help='version to meta.conf')
    parser.add_argument('-t', '--train_config', type=str, help='path to train config')
    parser.add_argument('-k', '--kestrel_config', type=str, help='path to kestrel config', default='')
    parser.add_argument('-a', '--anchor', type=str, help='path to anchor.json', default='')
    parser.add_argument('-n', '--name', type=str, default='None', help='compressed model name')
    parser.add_argument('-p', '--save_path', help='path to save model', default='.')
    parser.add_argument('-b', '--max_batch_size', type=int, help='max batch size', default=8)
    parser.add_argument('-s', '--serialize', action='store_true', help='serialize fp32 model', default=False)
    args = parser.parse_args()

    # check meta version format
    version = scaffold.check_version_format(args.version)

    # get param from pod config
    kestrel_param, bbox_head_type = generate_config(args.train_config, args.kestrel_config, args.anchor)

    # process_net
    cls_num = len(kestrel_param['class']) + 1
    anchor_num = len(kestrel_param['anchor_ratios']) * len(kestrel_param['anchor_scales'])
    rpn_net, det_net, net_info = process_net(args.prototxt, args.model,
                                             anchor_num, cls_num,
                                             kestrel_param['short_scale'],
                                             kestrel_param['long_scale'],
                                             bbox_head_type)

    net_info['rpn']['packname'] = 'proposal'
    net_info['det']['packname'] = 'detection'
    net_info['rpn']['backend'] = 'kestrel_caffe'
    net_info['det']['backend'] = 'kestrel_caffe'
    rpn_path = scaffold.generate_model(rpn_net, args.save_path, net_info['rpn']['packname'])
    scaffold.generate_model(det_net, args.save_path, net_info['det']['packname'])

    if args.serialize:
        net_info['rpn']['packname'] = 'rpn_engine.bin'
        net_info['rpn']['backend'] = 'kestrel_mixnet'
        engine_path = os.path.join(args.save_path, net_info['rpn']['packname'])
        config = {'output_names': [net_info['rpn']['feature']]}
        scaffold.serialize(rpn_path, args.max_batch_size, engine_path, config)

    common_param = generate_common_param(net_info, args.max_batch_size,
                                         kestrel_param['aft_top_k'])
    kestrel_param['model_files'] = common_param

    scaffold.generate_json_file(os.path.join(args.save_path, 'parameters.json'),kestrel_param)

    scaffold.generate_meta(args.save_path, args.name, 'harpy', version, {'class': kestrel_param['class']})

    scaffold.compress_model(args.save_path, [net_info['rpn']['packname'], net_info['det']['packname']], args.name, version)
