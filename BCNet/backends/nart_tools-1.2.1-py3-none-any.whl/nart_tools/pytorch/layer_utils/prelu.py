from .layer import Layer

class PReLU(Layer):

    def set_top(self):
        self.params.top.extend(self.node.output)

    def set_bottom(self):
        self.params.bottom.extend(self.node.input[0:1])

    def set_param(self):
        weight_blob = self.network.blobs[self.node.input[1]]
        self.params.blobs.extend([Layer.array_to_blobproto(weight_blob)])
        if len(self.params.blobs[0].data) == 1:
            self.params.prelu_param.channel_shared = True
            self.params.blobs[0].shape.dim.pop()

    def set_blobshape(self):
        self.network.blobshape[self.params.top[0]] = self.network.blobshape[self.params.bottom[0]]