from .layer import Layer
from ...proto import caffe_pb2
import math

class Pooling(Layer):

    def set_top(self):
        self.params.top.extend(self.node.output)
    
    def set_bottom(self):
        self.params.bottom.extend(self.node.input)

    def set_param(self):
        if self.node.op_type == 'MaxPool':
            self.params.pooling_param.pool = caffe_pb2.PoolingParameter.MAX
        elif self.node.op_type == 'AveragePool':
            self.params.pooling_param.pool = caffe_pb2.PoolingParameter.AVE

        attributes = dict(zip([attr.name for attr in self.node.attribute], self.node.attribute))
        if attributes['ceil_mode'].i != 1:
            self.params.pooling_param.ceil_mode = attributes['ceil_mode'].i

        self.params.pooling_param.kernel_h = attributes['kernel_shape'].ints[0] 
        self.params.pooling_param.kernel_w = attributes['kernel_shape'].ints[1] 

        self.params.pooling_param.pad_h = attributes['pads'].ints[0] 
        self.params.pooling_param.pad_w = attributes['pads'].ints[1] 

        self.params.pooling_param.stride_h = attributes['strides'].ints[0]
        self.params.pooling_param.stride_w = attributes['strides'].ints[1]
    
    def set_blobshape(self):
        n, c, h, w = self.network.blobshape[self.params.bottom[0]]

        if self.params.pooling_param.ceil_mode:
           h = math.ceil((h + 2 * self.params.pooling_param.pad_h - self.params.pooling_param.kernel_h) \
                        / self.params.pooling_param.stride_h + 1)
           w = math.ceil((w + 2 * self.params.pooling_param.pad_w - self.params.pooling_param.kernel_w) \
                        / self.params.pooling_param.stride_w + 1)
        else:
           h = math.floor((h + 2 * self.params.pooling_param.pad_h - self.params.pooling_param.kernel_h) \
                        / self.params.pooling_param.stride_h + 1)
           w = math.floor((w + 2 * self.params.pooling_param.pad_w - self.params.pooling_param.kernel_w) \
                        / self.params.pooling_param.stride_w + 1)
        self.network.blobshape[self.params.top[0]] = [n, c, h, w]