from abc import ABC, abstractmethod
from ...proto import caffe_pb2

class Layer(ABC):

    def __init__(self, node, index, network):
        self.params = caffe_pb2.LayerParameter(
            type=self.__class__.__name__,
            name=self.__class__.__name__ + '_' + str(index))
        self.node = node
        self.network = network
        self.set_top()
        self.set_bottom()
        self.set_param()
        self.set_blobshape()

    @abstractmethod
    def set_top(self):
        raise NotImplementedError

    @abstractmethod
    def set_bottom(self):
        raise NotImplementedError

    @abstractmethod
    def set_param(self):
        raise NotImplementedError

    @abstractmethod
    def set_blobshape(self):
        raise NotImplementedError

    @staticmethod
    def array_to_blobproto(arr, diff=None):
        """
        Converts a N-dimensional array to blob proto. 
        If diff is given, also convert the diff. 
        You need to make sure that arr and diff have the same
        shape, and this function does not do sanity check.
        """
        blob = caffe_pb2.BlobProto()
        blob.shape.dim.extend(arr.shape)
        blob.data.extend(arr.astype(float).flat)
        if diff is not None:
            blob.diff.extend(diff.astype(float).flat)
        return blob