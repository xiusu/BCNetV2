from .layer import Layer
from functools import reduce

class Reshape(Layer):

    def set_top(self):
        self.params.top.extend(self.node.output)

    def set_bottom(self):
        self.params.bottom.extend(self.node.input)

    def set_param(self):
        attributes = dict(zip([attr.name for attr in self.node.attribute], self.node.attribute))
        if self.node.op_type == 'Squeeze':
            shape = self.network.blobshape[self.params.bottom[0]].copy()
            for axis in sorted(attributes['axes'].ints, reverse=True):
                shape.pop(axis)
            self.params.reshape_param.shape.dim.extend(shape)
        elif self.node.op_type == 'Unsqueeze':
            shape = self.network.blobshape[self.params.bottom[0]].copy()
            for axis in attributes['axes'].ints:
                shape.insert(axis, 1)
            self.params.reshape_param.shape.dim.extend(shape)
        elif self.node.op_type == 'Flatten':
            bottom_shape = self.network.blobshape[self.params.bottom[0]]
            shape = []
            for axis in range(attributes['axis'].i):
                shape.append(bottom_shape[axis])
            shape.append(-1)
            self.params.reshape_param.shape.dim.extend(shape)
        else:
            if 'shape' in attributes.keys():
                self.params.reshape_param.shape.dim.extend(attributes['shape'].ints)
            elif 'dims' in attributes.keys():
                bottom_shape = self.network.blobshape[self.params.bottom[0]]
                shape = []
                for dim in attributes['dims'].ints:
                    if dim == -1:
                        shape.append(dim)
                    else:
                        shape.append(bottom_shape[dim])
                self.params.reshape_param.shape.dim.extend(shape)

    def set_blobshape(self):
        bottom_shape = self.network.blobshape[self.params.bottom[0]]
        top_shape = self.params.reshape_param.shape.dim[:]

        infer_idx = None
        for idx in range(len(top_shape)):
            dim = top_shape[idx]
            if dim == -1: 
                infer_idx = idx
            elif dim == 0:
                top_shape[idx] = bottom_shape[idx]
        if infer_idx is not None:
            num_items = reduce(lambda a, b: a * b, bottom_shape)        
            accounted_items = reduce(lambda a, b: a * b, [dim for dim in top_shape if dim != -1])
            top_shape[infer_idx] = num_items // accounted_items 
        self.network.blobshape[self.params.top[0]] = top_shape 