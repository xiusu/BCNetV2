import warnings

def remove_cast_nodes(model):
    '''
    Cast node can be safely abandoned in caffe.
    This method removes the redundant cast slice nodes. 
    ''' 
    nodes = model.graph.node[:]
    del model.graph.node[:]

    as_input = dict()
    as_output = dict()
    for node in nodes: 
        for inp in node.input:
            if inp not in as_input.keys():
                as_input[inp] = []
            as_input[inp].append(node)
        for output in node.output:
            if output not in as_output.keys():
                as_output[output] = []
            as_output[output].append(node)

    filtered_nodes = []
    for cast_node in nodes:
        if cast_node.op_type != 'Cast':
            filtered_nodes.append(cast_node)
            continue
        inp = cast_node.input[0]
        output = cast_node.output[0]
        message = '[PRECISION WARNING] Cast node (input: {}, output: {}) automatically abandoned.\n'.format(inp, output)
        message += ' This may cause precision loss.'
        warnings.warn(message)

        if inp not in as_output.keys() or len(as_output[inp]) == 0:
            # not the output of any node, it must be
            # the original input of network
            for i in range(len(model.graph.input)):
                if model.graph.input[i].name == inp:
                    model.graph.input[i].name = output
                    break
            continue

        for node in as_output[inp]:
            for i in range(len(node.output)):
                if node.output[i] == inp:
                    node.output[i] = output
                    break

    model.graph.node.extend(filtered_nodes)