from .layer import Layer

class ReLU(Layer):

    def set_top(self):
        self.params.top.extend(self.node.output)

    def set_bottom(self):
        self.params.bottom.extend(self.node.input)

    def set_param(self):
        attributes = dict(zip([attr.name for attr in self.node.attribute], self.node.attribute))
        if 'alpha' in attributes.keys():
            self.params.relu_param.negative_slope = attributes['alpha'].f

    def set_blobshape(self):
        self.network.blobshape[self.params.top[0]] = self.network.blobshape[self.params.bottom[0]]