from .convolution import Convolution
from .holeconvolution import HoleConvolution
from .pooling import Pooling
from .relu import ReLU
from .inner_product import InnerProduct 
from .reshape import Reshape
from .batchnorm import BatchNorm
from .scale import Scale
from .eltwise import Eltwise
from .prelu import PReLU
from .interp import Interp
from .nninterp import NNInterp
from .slice import Slice
from .concat import Concat
from .sigmoid import Sigmoid
from .softmax import Softmax
from .roipool import ROIPool
from .roialign import ROIAlign
from .psroipooling import PSROIPooling
from .psroimaskpooling import PSROIMaskPooling
from .dropout import Dropout
from .transpose import Transpose
from .relu6 import ReLU6
from .clip import Clip
from .deconvolution import Deconvolution
from .shuffle_channel import ShuffleChannel
from .tanh import TanH
from .lstm_unit import LSTMUnit
from .sllstm import SLLSTM
from .slgrnn import SLGRNN
from .reverse import Reverse
from .groupnorm import GroupNorm
from .dummy_data import DummyData
from .unknown import Unknown
import warnings

__all__ = ['make_layers']

def make_layers(node, index, network):
    if node.op_type == 'Conv': 
        attributes = dict(zip([attr.name for attr in node.attribute], node.attribute))
        if attributes['dilations'].ints[0] == 1 and attributes['dilations'].ints[1] == 1:
            convolution_layer = Convolution(node, index, network)
            return [convolution_layer]
        else:
            holeconvolution_layer = HoleConvolution(node, index, network) 
            return [holeconvolution_layer]
    elif node.op_type in ["MaxPool", "AveragePool"]:
        pooling_layer = Pooling(node, index, network)
        return [pooling_layer]
    elif node.op_type in ['Relu', 'LeakyRelu']:
        relu_layer = ReLU(node, index, network)
        return [relu_layer]
    elif node.op_type == 'Gemm':
        inner_product_layer = InnerProduct(node, index, network)
        return [inner_product_layer]
    elif node.op_type in ['Reshape', 'Flatten', 'Squeeze', 'Unsqueeze']:
        reshape_layer = Reshape(node, index, network)
        return [reshape_layer]
    elif node.op_type == 'BatchNormalization':
        affine = True if node.input[1] and node.input[2] else False
        if affine:
            batchnorm_top = 'BatchNorm{}'.format(index)
            scale_top = node.output[0]
            node.output[0] = batchnorm_top
            batchnorm_layer = BatchNorm(node, index, network)
            node.input[0] = batchnorm_top
            node.output[0] = scale_top
            scale_layer = Scale(node, index, network) 
            return [batchnorm_layer, scale_layer]
        else:
            batchnorm_layer = BatchNorm(node, index, network)
            return [batchnorm_layer]
    elif node.op_type in ['Add', 'Mul', 'Max']:
        eltwise_layer = Eltwise(node, index, network)
        return [eltwise_layer]
    elif node.op_type == 'PRelu':
        prelu_layer = PReLU(node, index, network)
        return [prelu_layer]
    elif node.op_type == 'Upsample':
        attributes = dict(zip([attr.name for attr in node.attribute], node.attribute))
        mode = attributes['mode'].s.decode('utf-8')
        if mode == 'bilinear':
            interp_layer = Interp(node, index, network) 
            return [interp_layer]
        elif mode == 'nearest': 
            nninterp_layer = NNInterp(node, index, network) 
            return [nninterp_layer]
        else:
            raise NotImplementedError(node.op_type, mode)
    elif node.op_type in ['Split', 'Slice']:
        slice_layer = Slice(node, index, network)
        return [slice_layer]
    elif node.op_type == 'Concat':
        concat_layer = Concat(node, index, network)
        return [concat_layer]
    elif node.op_type == 'Sigmoid':
        sigmoid_layer = Sigmoid(node, index, network)
        return [sigmoid_layer]
    elif node.op_type == 'Softmax':
        softmax_layer = Softmax(node, index, network)
        return [softmax_layer]
    elif node.op_type == 'RoiAlign':
        roialign_layer = ROIAlign(node, index, network)
        return [roialign_layer]
    elif node.op_type == 'RoiPool':
        roipool_layer = ROIPool(node, index, network)
        return [roipool_layer]
    elif node.op_type == 'PSRoiPool':
        psroipooling_layer = PSROIPooling(node, index, network)
        return [psroipooling_layer]
    elif node.op_type == 'PSRoiMaskPool':
        psroimaskpooling_layer = PSROIMaskPooling(node, index, network)
        return [psroimaskpooling_layer]
    elif node.op_type == 'Dropout':
        dropout_layer = Dropout(node, index, network)
        return [dropout_layer]
    elif node.op_type == 'Transpose':
        transpose_layer = Transpose(node, index, network)
        return [transpose_layer]
    elif node.op_type == 'Hardtanh':
        attributes = dict(zip([attr.name for attr in node.attribute], node.attribute))
        if int(attributes['min_val'].f) == 0 and int(attributes['max_val'].f) == 6:
            relu6_layer = ReLU6(node, index, network)
            return [relu6_layer]
        else:
            clip_layer = Clip(node, index, network)
            return [clip_layer]
    elif node.op_type == 'Clip':
        attributes = dict(zip([attr.name for attr in node.attribute], node.attribute))
        if int(attributes['min'].f) == 0 and int(attributes['max'].f) == 6:
            relu6_layer = ReLU6(node, index, network)
            return [relu6_layer]
        else:
            clip_layer = Clip(node, index, network)
            return [clip_layer]
    elif node.op_type == 'ConvTranspose':
        deconvolution_layer = Deconvolution(node, index, network)
        return [deconvolution_layer]
    elif node.op_type == 'ShuffleChannel':
        shuffle_channel_layer = ShuffleChannel(node, index, network)
        return [shuffle_channel_layer]
    elif node.op_type == 'Tanh':
        tanh_layer = TanH(node, index, network)
        return [tanh_layer]
    elif node.op_type == 'LSTMCell':
        lstm_unit_layer = LSTMUnit(node, index, network)
        return [lstm_unit_layer]
    elif node.op_type == 'LSTM':
        sllstm_layer = SLLSTM(node, index, network)
        return [sllstm_layer]
    elif node.op_type == 'GRU':
        slgrnn_layer = SLGRNN(node, index, network)
        return [slgrnn_layer]
    elif node.op_type == 'Flip':
        reverse_layer = Reverse(node, index, network)
        return [reverse_layer]
    elif node.op_type == 'GroupNorm':
        affine = True if len(node.input) > 1 else False
        if affine:
            groupnorm_top = 'GroupNorm{}'.format(index)
            scale_top = node.output[0]
            node.output[0] = groupnorm_top
            groupnorm_layer = GroupNorm(node, index, network)
            node.input[0] = groupnorm_top
            node.output[0] = scale_top
            scale_layer = Scale(node, index, network) 
            return [groupnorm_layer, scale_layer]
        else:
            groupnorm_layer = GroupNorm(node, index, network)
            return [groupnorm_layer]
    elif node.op_type == 'Constant':
        dummy_data_layer = DummyData(node, index, network) 
        warnings.warn('[FATAL WARNING] DummyData layer {} occured. '.format(dummy_data_layer.params.name) + \
                      'Please manually modify the prototxt file.')
        return [dummy_data_layer]
    else:
        #raise NotImplementedError(node.op_type)
        unknown_layer = Unknown(node, index, network) 
        message = '[FATAL WARNING] Unknown layer {} occured from {}. Please manually modify the prototxt file.\n'\
            .format(unknown_layer.params.name, node.op_type)
        warnings.warn(message)
        return [unknown_layer]
