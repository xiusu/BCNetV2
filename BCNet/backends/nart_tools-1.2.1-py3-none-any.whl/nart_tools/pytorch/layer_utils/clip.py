from .layer import Layer

class Clip(Layer):

    def set_top(self):
        self.params.top.extend(self.node.output)

    def set_bottom(self):
        self.params.bottom.extend(self.node.input)

    def set_param(self):
        attributes = dict(zip([attr.name for attr in self.node.attribute], self.node.attribute))
        if self.node.op_type == 'Hardtanh':
            self.params.clip_param.min_val = attributes['min_val'].f
            self.params.clip_param.max_val = attributes['max_val'].f
        elif self.node.op_type == 'Clip':
            self.params.clip_param.min_val = attributes['min'].f
            self.params.clip_param.max_val = attributes['max'].f

    def set_blobshape(self):
        self.network.blobshape[self.params.top[0]] = self.network.blobshape[self.params.bottom[0]]