from .layer import Layer

class Slice(Layer):

    def set_top(self):
        #assert len(self.node.output) > 1
        self.params.top.extend(self.node.output)

    def set_bottom(self):
        self.params.bottom.extend(self.node.input)

    def set_param(self):
        attributes = dict(zip([attr.name for attr in self.node.attribute], self.node.attribute))
        if self.node.op_type == 'Split':
            self.params.slice_param.axis = attributes['axis'].i
            slice_point = 0
            for split in attributes['split'].ints[:-1]:
                slice_point += split
                self.params.slice_param.slice_point.extend([slice_point])
        elif self.node.op_type == 'Slice':
            assert len(attributes['axes'].ints) == 1
            assert len(attributes['starts'].ints) == len(attributes['ends'].ints)
            self.params.slice_param.axis = attributes['axes'].ints[0]
            starts = set(attributes['starts'].ints) 
            ends = set(attributes['ends'].ints) 
            slice_points = sorted(list(starts.union(ends)))
            self.params.slice_param.slice_point.extend(slice_points[1:-1])

    def set_blobshape(self):
        axis = self.params.slice_param.axis
        bottom_shape = self.network.blobshape[self.params.bottom[0]]
        start = 0
        for i in range(len(self.params.top)):
            top_shape = bottom_shape[:]
            if i == len(self.params.top) - 1:
                top_shape[axis] = bottom_shape[axis] - start
            else:
                top_shape[axis] = self.params.slice_param.slice_point[i] - start
                start = self.params.slice_param.slice_point[i]
            self.network.blobshape[self.params.top[i]] = top_shape