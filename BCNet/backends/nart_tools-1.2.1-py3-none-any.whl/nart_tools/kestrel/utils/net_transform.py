#!/usr/bin/env python
# -*- coding: utf-8 -*-
import nart_tools.caffe.convert as convert
import nart_tools.proto.caffe_pb2 as caffe_pb2
import nart_tools.caffe.utils.graph as graph

def static_var(varname, value):
    def decorate(func):
        setattr(func, varname, value)
        return func
    return decorate

def get_node(net_graph, layer):
    for i in net_graph.nodes():
        if i.content == layer:
            return i

@static_var('cnt', 0)
def add_transpose(net, net_graph, prev_layer, name, transpose_param, insert=True):
    prev_node = get_node(graph.gen_graph(net), prev_layer)
    old_top_name = prev_layer.top[0]
    new_top_name = 'transpose_out' + str(add_transpose.cnt)

    layer = caffe_pb2.LayerParameter()
    layer.name = 'transpose_' + name + str(add_transpose.cnt)
    layer.type = 'Transpose'
    layer.bottom.append(old_top_name)
    layer.top.append(new_top_name)
    layer.transpose_param.dim.extend(transpose_param)
    if insert:
        # update succeed nodes' bottom
        for succ in prev_node.succ:
            succ.content.bottom.remove(old_top_name)
            succ.content.bottom.append(new_top_name)
    idx = convert.insertNewLayer(layer, prev_layer.name, net)
    convert.updateNetGraph(net, net_graph)

    add_transpose.cnt += 1
    return net.layer[idx]

@static_var('cnt', 0)
def add_sigmoid(net, net_graph, prev_layer, name, insert=True):
    prev_node = get_node(graph.gen_graph(net), prev_layer)
    old_top_name = prev_layer.top[0]
    new_top_name = 'sigmoid_out' + str(add_sigmoid.cnt)

    layer = caffe_pb2.LayerParameter()
    layer.name = 'sigmoid_' + name + str(add_sigmoid.cnt)
    layer.type = 'Sigmoid'
    layer.bottom.append(old_top_name)
    layer.top.append(new_top_name)
    if insert:
        # update succeed nodes' bottom
        for succ in prev_node.succ:
            succ.content.bottom.remove(old_top_name)
            succ.content.bottom.append(new_top_name)
    idx = convert.insertNewLayer(layer, prev_layer.name, net)
    convert.updateNetGraph(net, net_graph)

    add_sigmoid.cnt += 1
    return net.layer[idx]

@static_var('cnt', 0)
def add_slice(net, net_graph, prev_layer, name, slice_point, axis, insert=True):
    prev_node = get_node(graph.gen_graph(net), prev_layer)
    old_top_name = prev_layer.top[0]
    new_top_name_0 = 'slice_fg' + str(add_slice.cnt)
    new_top_name_1 = 'slice_bg' + str(add_slice.cnt)

    layer = caffe_pb2.LayerParameter()
    layer.name = 'slice_' + name + str(add_slice.cnt)
    layer.type = 'Slice'
    layer.bottom.append(old_top_name)
    layer.top.append(new_top_name_0)
    layer.top.append(new_top_name_1)
    layer.slice_param.slice_point.append(slice_point)
    layer.slice_param.axis = axis
    if insert:
        # update succeed nodes' bottom
        for succ in prev_node.succ:
            succ.content.bottom.remove(old_top_name)
            succ.content.bottom.extend([new_top_name_0, new_top_name_1])
    idx = convert.insertNewLayer(layer, prev_layer.name, net)
    convert.updateNetGraph(net, net_graph)

    add_slice.cnt += 1
    return net.layer[idx]

@static_var('cnt', 0)
def add_heatmap2coord(net, net_graph, prev_layer, name, coord_h, coord_w, coord_reposition, insert=True):
    prev_node = get_node(graph.gen_graph(net), prev_layer)
    old_top_name = prev_layer.top[0]
    new_top_name = 'heatmap2coord_out' + str(add_heatmap2coord.cnt)

    layer = caffe_pb2.LayerParameter()
    layer.name = 'heatmap2coord_' + name + str(add_heatmap2coord.cnt)
    layer.type = 'HeatMap2Coord'
    layer.bottom.append(old_top_name)
    layer.top.append(new_top_name)
    layer.heatmap_param.coord_h = coord_h
    layer.heatmap_param.coord_w = coord_w
    layer.heatmap_param.coord_reposition = coord_reposition
    if insert:
        # update succeed nodes' bottom
        for succ in prev_node.succ:
            succ.content.bottom.remove(old_top_name)
            succ.content.bottom.append(new_top_name)
    idx = convert.insertNewLayer(layer, prev_layer.name, net)
    convert.updateNetGraph(net, net_graph)

    add_heatmap2coord.cnt += 1
    return net.layer[idx]

def remove_layer(net, node):
    print('romove layer: {}'.format(node.content.name))
    assert len(node.content.bottom) == 1
    assert len(node.content.top) == 1
    # update structure
    for succ in node.succ:
        succ.content.bottom.remove(node.content.top[0])
        succ.content.bottom.append(node.content.bottom[0])
        if (succ not in node.prev[0].succ):
            node.prev[0].succ.append(succ)
        if node.prev[0] not in succ.prev:
            succ.prev.append(node.prev[0])
    net.layer.remove(node.content)
