#encoding: utf-8
import numpy as np

def get_anchors_over_grid(ratios, scales, stride):
    """
    Generate anchor (reference) windows by enumerating aspect ratios X
    scales wrt a reference (0, 0, stride-1, stride-1) window.
    """
    # ratios, scales = np.meshgrid(ratios, scales)
    scales = np.array(scales) * stride
    return generate_anchors(stride=stride, sizes=scales, aspect_ratios=ratios)

    scales, ratios = np.meshgrid(scales, ratios)
    sqrt_ratios = np.sqrt(ratios)
    ws = (scales / sqrt_ratios).reshape(-1,1)
    hs = (scales * sqrt_ratios).reshape(-1,1)
    x = np.round(ws / 2.0)
    y = np.round(hs / 2.0)
    return np.hstack([-x,-y,x,y]) + stride / 2

def get_anchors_over_plane(featmap_h, featmap_w, anchor_ratios, anchor_scales, anchor_stride):
    # get anchors over one grid
    anchors_overgrid = get_anchors_over_grid(anchor_ratios, anchor_scales, anchor_stride)
    # spread anchors over each grid
    shift_x = np.arange(0, featmap_w) * anchor_stride
    shift_y = np.arange(0, featmap_h) * anchor_stride
    # [featmap_h, featmap_w]
    shift_x, shift_y = np.meshgrid(shift_x, shift_y)
    shifts = np.vstack((shift_x.ravel(), shift_y.ravel(),
                        shift_x.ravel(), shift_y.ravel())).transpose()
    A = anchors_overgrid.shape[0]
    K = shifts.shape[0]
    anchors_overplane = (anchors_overgrid.reshape((1, A, 4)) +
                    shifts.reshape((1, K, 4)).transpose((1, 0, 2)))
    return anchors_overplane.reshape((K * A, 4))

def generate_anchors(
    stride=16, sizes=(32, 64), aspect_ratios=(0.5, 1, 2)
):
    """Generates a matrix of anchor boxes in (x1, y1, x2, y2) format. Anchors
    are centered on stride / 2, have (approximate) sqrt areas of the specified
    sizes, and aspect ratios as given.
    """
    return _generate_anchors(
        stride,
        np.array(sizes, dtype=np.float) / stride,
        np.array(aspect_ratios, dtype=np.float)
    )
def _generate_anchors(base_size, scales, aspect_ratios):
    """Generate anchor (reference) windows by enumerating aspect ratios X
    scales wrt a reference (0, 0, base_size - 1, base_size - 1) window.
    """
    anchor = np.array([1, 1, base_size, base_size], dtype=np.float) - 1
    anchors = _ratio_enum(anchor, aspect_ratios)
    anchors = np.vstack(
        [_scale_enum(anchors[i, :], scales) for i in range(anchors.shape[0])]
    )
    return anchors
def _ratio_enum(anchor, ratios):
    """Enumerate a set of anchors for each aspect ratio wrt an anchor."""
    w, h, x_ctr, y_ctr = _whctrs(anchor)
    size = w * h
    size_ratios = size / ratios
    ws = np.round(np.sqrt(size_ratios))
    hs = np.round(ws * ratios)
    anchors = _mkanchors(ws, hs, x_ctr, y_ctr)
    return anchors
def _scale_enum(anchor, scales):
    """Enumerate a set of anchors for each scale wrt an anchor."""
    w, h, x_ctr, y_ctr = _whctrs(anchor)
    ws = w * scales
    hs = h * scales
    anchors = _mkanchors(ws, hs, x_ctr, y_ctr)
    return anchors
def _whctrs(anchor):
    """Return width, height, x center, and y center for an anchor (window)."""
    w = anchor[2] - anchor[0] + 1
    h = anchor[3] - anchor[1] + 1
    x_ctr = anchor[0] + 0.5 * (w - 1)
    y_ctr = anchor[1] + 0.5 * (h - 1)
    return w, h, x_ctr, y_ctr
def _mkanchors(ws, hs, x_ctr, y_ctr):
    """Given a vector of widths (ws) and heights (hs) around a center
    (x_ctr, y_ctr), output a set of anchors (windows).
    """
    ws = ws[:, np.newaxis]
    hs = hs[:, np.newaxis]
    anchors = np.hstack(
        (
            x_ctr - 0.5 * (ws - 1),
            y_ctr - 0.5 * (hs - 1),
            x_ctr + 0.5 * (ws - 1),
            y_ctr + 0.5 * (hs - 1)
        )
    )
    return anchors

