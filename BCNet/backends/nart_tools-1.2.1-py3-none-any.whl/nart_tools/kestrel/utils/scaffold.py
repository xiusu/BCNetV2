#!/usr/bin/env python
# -*- coding: utf-8 -*-
import re
import json
import os
import subprocess

import nart_tools.caffe.convert as convert

def check_version_format(content):
    pattern = '\d+.\d+.\d+'
    result = re.match(pattern, content)
    if result is None:
        print('Invalid meta version, use default 1.0.0')
        version = [1, 0, 0]
    else:
        version = [int(i) for i in content.split('.')]
    return version

def generate_meta(path, name, typ, version, cfg=dict(), desc=''):
    temp = """version {{
    major: {major}
    minor: {minor}
    patch: {patch}
    train_date: "{date}"
}}
model_name: "{name}"
model_type: "{typ}"
description: "{desc}"
"""

    import datetime
    date = datetime.date.today().strftime("%Y%m%d")
    s = temp.format(major=version[0], minor=version[1], patch=version[2],
                date=date, name=name, typ=typ, desc=desc)

    with open(path + "/meta.conf", "w") as f:
        f.write(s)
    print('generate {}'.format(os.path.join(path, 'meta.conf')))

    meta_json = dict()
    meta_json['model_name'] = name
    meta_json['model_type'] = typ
    meta_json['version'] = {
        'major': version[0],
        'minor': version[1],
        'patch': version[2],
        'train_date': date
    }
    meta_json['properties'] = {
        'description': desc
    }
    meta_json['configuration'] = cfg
    temp = """{{
    "model_name": "{name}",
    "model_type": "{typ}",
    "version": {{
        "major": {major},
        "minor": {minor},
        "patch": {patch},
        "train_date": "{date}"
    }},
    "properties": {{
        "description": "{desc}"
    }},
    "configuration": {cfg}
}}"""
    generate_json_file(os.path.join(path, 'meta.json'), meta_json)


def generate_model(net, prefix, packname):
    path = os.path.join(prefix, packname)
    if not os.path.exists(path):
        os.makedirs(path)
    with open(path + '/model.bin', 'wb') as f:
        f.write(net.SerializeToString())
    for layer in net.layer:
        layer.ClearField('blobs')
    with open(path + '/rel.prototxt', 'w') as f:
        f.write(str(net))
    print('save model to {}'.format(path))
    return path


def compress_model(path, packnames, name, version):
    files = [
        'meta.conf',
        'meta.json',
        'parameters.json'
    ]
    files.extend(packnames)
    model_name = name + '_' + '.'.join([str(i) for i in version])
    cmd = 'cd {} && tar -cvf {}.tar {}'.format(path, model_name, ' '.join(files))
    print(cmd)
    p = subprocess.Popen(cmd, shell = True)
    p.wait()
    print('generate model {}.tar'.format(os.path.join(path, model_name)))

def generate_json_file(path, json_dict):
    with open(path, 'w') as f:
        f.write(json.dumps(json_dict, indent=4))
    print('generate {}'.format(path))

def merge_bn(net):
    try:
        net = convert.mergeLayers(
                net,
                handleBlob=True,
                batchnorm=True,
                bn=True,
                scale=True,
                bns=True,
                BNs=True,
                verbose=True
        )
    except:
        print('merge bn fail')
    return net

def update_input_dim(net, idx, shape):
    assert len(net.input_dim) < 1 or len(net.input_shape) < 1
    assert len(net.input_dim) > 0 or len(net.input_shape) > 0
    if len(net.input_dim) > 0:
        assert len(net.input_dim) >= (idx + 1) * 4
        net.input_dim[idx * 4 + 0] = shape[0]
        net.input_dim[idx * 4 + 1] = shape[1]
        net.input_dim[idx * 4 + 2] = shape[2]
        net.input_dim[idx * 4 + 3] = shape[3]
        print('set input_dim to: {}'.format(shape))
    if len(net.input_shape) > 0:
        assert len(net.input_shape) >= idx + 1
        for i in net.input_shape:
            assert len(i.dim) == 4
        net.input_shape[idx].ClearField('dim')
        net.input_shape[idx].dim.extend(shape)
        print('set input_dim to: {}'.format(shape))

def serialize(model_path, max_batch_size, engine_path, config=None):
    print('serialize to fp32 engine')
    if (config is None):
        cmd = 'serialize_tool -t MIXFP32 {} {} -b {} -o {}'.format(
            os.path.join(model_path, 'rel.prototxt'),
            os.path.join(model_path, 'model.bin'),
            max_batch_size,
            engine_path
        )
    else:
        config_file = os.path.join(os.path.dirname(engine_path), 'serialize_config.json')
        with open(config_file, 'w') as f:
            f.write(json.dumps(config, indent=4))
        cmd = 'serialize_tool -t MIXFP32 {} {} -b {} -o {} -c {}'.format(
            os.path.join(model_path, 'rel.prototxt'),
            os.path.join(model_path, 'model.bin'),
            max_batch_size,
            engine_path,
            config_file
        )

    print(cmd)
    p = subprocess.Popen(cmd, shell = True)
    p.wait()

