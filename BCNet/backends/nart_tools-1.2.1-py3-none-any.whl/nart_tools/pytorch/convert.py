import torch
import sys
from torch.autograd import Variable
from os.path import splitext, getsize
from .onnx_utils.onnx_helper import load
from .network_utils import make_network
from .module_utils import convert_mode
import threading
from ..io import send

def convert(model, input_shapes, filename, log=True,
            input_names=None, output_names=None, input_dict=None,
            verbose=False, output_weights=True, cloze=True):
    '''
    Convert a pytorch model into a caffe model
    @params:
    model: the pytorch model to be converted
    input_shapes: list of ints of the shape of model input
    filename: the file name (without postfix) to be saved for the caffe model
    log: indicate whether to log this call
    input_names: list of strs of the name of model input
    output_names: list of strs of the name of model output
    input_dict: dict of model configs except those of 'image' key
    verbose: indicate whether the detailed structure of model is displayed
    output_weights: indicate whether the weight file of caffe model is generated
    cloze: indicate whether to add a "1" at the head of each input shape
    '''
    custom_info = {"Method": "convert", "Module": "nart_tools"}
    try:
        export_onnx(model, input_shapes, filename, log=False,
                    input_dict=input_dict, verbose=verbose, cloze=cloze)
        convert_onnx(filename + '.onnx', log=False, input_names=input_names, 
                    output_names=output_names, verbose=verbose, output_weights=output_weights)
        custom_info["Status"] = "Success" 
        custom_info["Caffe Model Size"] = '{} Bytes'.format(getsize(filename + '.caffemodel'))
        custom_info["ONNX Model Size"] = '{} Bytes'.format(getsize(filename + '.onnx'))
    except Exception as e:
        custom_info["Status"] = str(e)
        raise e
    finally:
        if log:
            log_thread = threading.Thread(target=send, args=(custom_info,))
            log_thread.start()

def export_onnx(model, input_shapes, filename, log=True, 
                input_dict=None, verbose=False, cloze=True):
    '''
    Convert a pytorch model into an onnx model
    @params:
    model: the pytorch model to be converted
    input_shapes: list of ints of the shape of model input
    filename: the file name (without postfix) to be saved for the onnx model
    log: indicate whether to log this call
    input_dict: dict of model configs except those of 'image' key
    verbose: indicate whether the detailed structure of model is displayed
    cloze: indicate whether to add a "1" at the head of each input shape
    '''
    if verbose:
        print("====convert: start of pytorch-to-onnx export")

    custom_info = {"Method": "export_onnx", "Module": "nart_tools"}
    try:
        model.cpu()
        model.eval()
        if input_dict is not None:
            print("Input dict is not None. Automatically setting cloze to be False.")
            cloze = False
        input_variables = Convert.substitute_shape(input_shapes, cloze)
        if input_dict is not None:
            input_dict['image'] = input_variables
            torch.onnx.export(model, (input_dict,), filename + ".onnx", verbose=verbose)
        else:
            torch.onnx.export(model, input_variables, filename + ".onnx", verbose=verbose)
        custom_info["Status"] = "Success" 
        custom_info["ONNX Model Size"] = '{} Bytes'.format(getsize(filename + '.onnx'))
    except Exception as e:
        custom_info["Status"] = str(e)
        raise e
    finally:
        if log:
            log_thread = threading.Thread(target=send, args=(custom_info,))
            log_thread.start()

    if verbose:
        print("====convert: end of pytorch-to-onnx export")

def convert_onnx(filename, log=True, input_names=None, output_names=None, 
                 verbose=False, output_weights=True):
    '''
    Convert an onnx model into a caffe model
    @params:
    filename: the file name (with postfix) of the onnx model
    log: indicate whether to log this call
    input_names: list of strs of the name of model input
    output_names: list of strs of the name of model output
    verbose: indicate whether the detailed structure of model is displayed
    output_weights: indicate whether the weight file of caffe model is generated
    '''
    if verbose:
        print("====convert: start of onnx-to-caffe export")

    custom_info = {"Method": "convert_onnx", "Module": "nart_tools"}
    try:
        model = load(filename)
        name = splitext(filename)[0]
        network = make_network(model, name, input_names, output_names)
        network.save(verbose=verbose, output_weights=output_weights)
        custom_info["Status"] = "Success" 
        custom_info["Caffe Model Size"] = '{} Bytes'.format(getsize(name + '.caffemodel'))
    except Exception as e:
        custom_info["Status"] = str(e)
        raise e
    finally:
        if log:
            log_thread = threading.Thread(target=send, args=(custom_info,))
            log_thread.start()

    if verbose:
        print("====convert: end of onnx-to-caffe export")

def rearrange_channel(filename, indices, log=True):
    '''
    ----毒瘤函数，无关人员速速退散----
    Rearrange the channel every 2 channels
    @params:
    filename: the name (without postfix) of the caffe model
    indices: the list of indices of the layers to be rearranged
    log: indicate whether to log this call
    ----版本旧约，对齐协议早早解脱----
    '''
    import numpy as np
    from ..proto import caffe_pb2
    if log:
        custom_info = {"Method": "rearrange_channel", "Module": "nart_tools"}
        log_thread = threading.Thread(target=send, args=(custom_info,))
        log_thread.start()

    net = caffe_pb2.NetParameter()
    with open(filename + '.caffemodel', 'rb') as fin:
        net.ParseFromString(fin.read())
    for layer in net.layer:
        layer_index = int(layer.name.split('_')[-1])
        if layer_index not in indices:
            continue
        weight = np.array(layer.blobs[0].data[:]) 
        span = weight.shape[0] // 2
        duliu = []
        for i in range(span):
            duliu.append(weight[2 * i])
        for i in range(span):
            duliu.append(weight[2 * i + 1])
        layer.blobs[0].data[:] = np.array(duliu)
    with open(filename + '.caffemodel', 'wb') as fout:
        fout.write(net.SerializeToString())

class Convert(sys.modules[__name__].__class__):

    @staticmethod
    def __call__(model, input_shapes, filename, log=True,
                input_names=None, output_names=None, input_dict=None,
                verbose=False, output_weights=True, cloze=True):
        convert(model, input_shapes, filename, log=log, 
                input_names=input_names, output_names=output_names, input_dict=input_dict, 
                verbose=verbose, output_weights=output_weights, cloze=cloze)

    @staticmethod
    def substitute_shape(input_shapes, cloze):
        input_variables = []
        for input_shape in input_shapes:
            if all(map(lambda shape: isinstance(shape, int), input_shape)):
                if cloze:
                    input_shape = [1] + list(input_shape)
                tensor = torch.randn(input_shape)
                variable = Variable(tensor, requires_grad=True)
                input_variables.append(variable)
            else:
                input_variables.append(Convert.substitute_shape(input_shape, cloze))
        return tuple(input_variables)

sys.modules[__name__].__class__ = Convert