import torch
from torch.autograd import Function

class FlipForward(Function):

    @staticmethod
    def forward(ctx, input, dims):
        assert len(dims) == 1
        dim = dims[0]
        size = input.size()
        dim = input.dim() + dim if dim < 0 else dim
        input = input.view(-1, *size[dim:])
        input = input.view(input.size(0), input.size(1), -1)[:, torch.arange(input.size(1) - 1, -1, -1).long(), :]
        return input.view(size)

    @staticmethod
    def symbolic(g, input, dims):
        return g.op("Flip", input, dims_i=dims)

def forward(input, dims):
    return FlipForward.apply(input, dims)