import google.protobuf.text_format as text_format
from ...proto import caffe_pb2 
from ..onnx_utils.onnx_helper import to_array 
from ..layer_utils import make_layers

class Network():

    def __init__(self, model, name):
        self.params = caffe_pb2.NetParameter(name=name)
        self.model = model 
        self.parse_blobs()
        self.parse_input()
        self.parse_layers()
    
    def parse_blobs(self):
        self.blobs = dict()
        for blob in self.model.graph.initializer:
            self.blobs[blob.name] = to_array(blob)

        self.blobshape = dict()
        for inp in self.model.graph.input:
            if inp.name not in self.blobs.keys():
                self.blobshape[inp.name] = [d.dim_value for d in inp.type.tensor_type.shape.dim]

    def parse_input(self):
        inps = [inp for inp in self.model.graph.input if inp.name not in self.blobs.keys()]
        self.params.input.extend([inp.name for inp in inps])
        for inp in inps:
            inp_shape = caffe_pb2.BlobShape()
            inp_shape.dim.extend([d.dim_value for d in inp.type.tensor_type.shape.dim])
            self.params.input_shape.extend([inp_shape])

    def parse_layers(self):
        for index, node in enumerate(self.model.graph.node):
            layers = make_layers(node, index, self)
            for layer in layers:
                self.params.layer.extend([layer.params])
        pass

    def save(self, verbose=False, output_weights=True):
        if verbose:
            print("Blobs dataflow of network {}:".format(self.params.name))
            for inp, inp_shape in zip(self.params.input, self.params.input_shape):
                shape = [int(dim[5:]) for dim in str(inp_shape).strip().split('\n')]
                print("Input blob '{}' with shape {}".format(inp, shape))
            output_names = set([output.name for output in self.model.graph.output])
            for layer in self.params.layer:
                for top in layer.top:
                    if top in output_names:
                        print("Output blob '{}' with shape {} as top of layer {}".
                                format(top, self.blobshape[top], layer.name))
                    else:
                        print("Blob '{}' with shape {} as top of layer {}".
                                format(top, self.blobshape[top], layer.name))

        proto = caffe_pb2.NetParameter()
        proto.CopyFrom(self.params)
        for layer in proto.layer:
            del layer.blobs[:]

        with open(self.params.name + '.prototxt', 'w') as fout:
            fout.write(text_format.MessageToString(proto))

        if output_weights:
            with open(self.params.name + '.caffemodel', 'wb') as fout:
                fout.write(self.params.SerializeToString())
