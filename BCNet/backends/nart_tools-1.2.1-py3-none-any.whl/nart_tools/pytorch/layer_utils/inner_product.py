from .layer import Layer

class InnerProduct(Layer):

    def set_top(self):
        self.params.top.extend(self.node.output)
    
    def set_bottom(self):
        self.params.bottom.extend(self.node.input[0:1])

    def set_param(self):
        weight_blob = self.network.blobs[self.node.input[1]]
        self.params.blobs.extend([Layer.array_to_blobproto(weight_blob)])
        self.params.inner_product_param.num_output = weight_blob.shape[0]

        if self.node.input[2] in self.network.blobs.keys():
            bias_blob = self.network.blobs[self.node.input[2]]
            self.params.blobs.extend([Layer.array_to_blobproto(bias_blob)])
            self.params.inner_product_param.bias_term = True
        else:
            self.params.inner_product_param.bias_term = False

    def set_blobshape(self):
        self.network.blobshape[self.params.top[0]] = \
            [self.network.blobshape[self.params.bottom[0]][0], 
             self.params.inner_product_param.num_output]