from .layer import Layer

class NNInterp(Layer):

    def set_top(self):
        self.params.top.extend(self.node.output)

    def set_bottom(self):
        self.params.bottom.extend(self.node.input)

    def set_param(self):
        attributes = dict(zip([attr.name for attr in self.node.attribute], self.node.attribute))
        self.params.nninterp_param.height = attributes['height'].i
        self.params.nninterp_param.width = attributes['width'].i 

    def set_blobshape(self):
        n, c = self.network.blobshape[self.params.bottom[0]][:2]
        h = self.params.nninterp_param.height 
        w = self.params.nninterp_param.width 
        self.network.blobshape[self.params.top[0]] = [n, c, h, w] 