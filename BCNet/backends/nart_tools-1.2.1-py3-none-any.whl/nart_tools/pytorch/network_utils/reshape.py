import numpy as np

def merge_reshape_nodes(model):
    '''
    Version specific for 0.4.1 and 1.0.x
    A sequence of constant-reshape nodes with consistent blob flow  
    corresponds to one holistic Reshape layer in caffe.
    This method merges the nodes into one node corresponding
    to that layer.
    ''' 
    nodes = model.graph.node[:]
    del model.graph.node[:]

    idx = 0
    while idx < len(nodes):
        node = nodes[idx]
        if node.op_type != 'Constant':
            model.graph.node.extend([node])
            idx += 1
            continue

        constant_node = node
        while idx < len(nodes):
            idx += 1
            if idx >= len(nodes):
                break
            node = nodes[idx]
            if node.op_type != 'Reshape':
                model.graph.node.extend([constant_node])
                break
            reshape_node = node
            assert constant_node.output[0] in reshape_node.input
            reshape_node.input.remove(constant_node.output[0])

            constant_attributes = dict(zip([attr.name for attr in constant_node.attribute], 
                                            constant_node.attribute))
            shape = np.frombuffer(constant_attributes['value'].t.raw_data, dtype=np.int64)
            reshape_node.attribute.add(ints=shape, name='shape')
            model.graph.node.extend([reshape_node])
            idx += 1
            break