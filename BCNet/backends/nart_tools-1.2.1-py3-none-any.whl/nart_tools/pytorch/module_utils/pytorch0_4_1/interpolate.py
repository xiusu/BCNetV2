import torch.nn.functional as F
from torch.autograd import Function
import warnings

class InterpolateForward(Function):

    @staticmethod
    def forward(ctx, input, size, scale_factor, mode, align_corners):
        return F.ori_interpolate(input, size, scale_factor, mode, align_corners)

    @staticmethod
    def symbolic(g, input, size, scale_factor, mode, align_corners):
        if scale_factor is not None:
            height = input.type().sizes()[2] * scale_factor
            width = input.type().sizes()[3] * scale_factor
        elif len(size) == 2:
            height = size[0]
            width = size[1]
        elif len(size == 1):
            height = size[0]
            width = size[0]
        return g.op("Upsample", input, mode_s=mode, height_i=height, width_i=width)

def forward(input, size=None, scale_factor=None, mode='nearest', align_corners=None):
    if mode == 'bilinear' and (align_corners is None or align_corners == False):
        message = "[PRECISION WARNING] CaffeInfer supports bilinear upsampling with align_corners == True.\n" 
        message += " Setting it False/None will cause performance loss."
        warnings.warn(message)
    return InterpolateForward.apply(input, size, scale_factor, mode, align_corners)