import torch.nn.functional as F
from torch.autograd import Function

class UpsampleForward(Function):

    @staticmethod
    def forward(ctx, input, size, scale_factor, mode, align_corners):
        return F.ori_upsample(input, size, scale_factor, mode, align_corners)

    @staticmethod
    def symbolic(g, input, size, scale_factor, mode, align_corners):
        if scale_factor is not None:
            height = input.type().sizes()[2] * scale_factor
            width = input.type().sizes()[3] * scale_factor
        elif len(size) == 2:
            height = size[0]
            width = size[1]
        elif len(size == 1):
            height = size[0]
            width = size[0]
        return g.op("Upsample", input, mode_s=mode, height_i=height, width_i=width)

def forward(input, size=None, scale_factor=None, mode='bilinear', align_corners=None):
    return UpsampleForward.apply(input, size, scale_factor, mode, align_corners)