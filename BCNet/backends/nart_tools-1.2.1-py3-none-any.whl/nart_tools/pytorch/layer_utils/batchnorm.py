from .layer import Layer
import numpy as np

class BatchNorm(Layer):

    def set_top(self):
        self.params.top.extend(self.node.output)

    def set_bottom(self):
        self.params.bottom.extend(self.node.input[0:1])

    def set_param(self):
        attributes = dict(zip([attr.name for attr in self.node.attribute], self.node.attribute))
        self.params.batch_norm_param.use_global_stats = attributes['is_test'].i
        self.params.batch_norm_param.moving_average_fraction = attributes['momentum'].f
        self.params.batch_norm_param.eps = attributes['epsilon'].f

        running_mean = self.network.blobs[self.node.input[3]]
        self.params.blobs.extend([Layer.array_to_blobproto(running_mean)])

        running_var = self.network.blobs[self.node.input[4]]
        self.params.blobs.extend([Layer.array_to_blobproto(running_var)])

        ones_blob = np.ones(1)
        self.params.blobs.extend([Layer.array_to_blobproto(ones_blob)])

    def set_blobshape(self):
        self.network.blobshape[self.params.top[0]] = self.network.blobshape[self.params.bottom[0]]