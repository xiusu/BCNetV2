from .layer import Layer

class Unknown(Layer):

    def set_top(self):
        self.params.top.extend(self.node.output)

    def set_bottom(self):
        self.params.bottom.extend(self.node.input)

    def set_param(self):
        pass

    def set_blobshape(self):
        for i in range(len(self.params.top)):
            self.network.blobshape[self.params.top[i]] = [1, 1, 1, 1] 