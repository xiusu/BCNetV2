#!/usr/bin/env python
# -*- coding: utf-8 -*-
import argparse
import yaml
import json
import os

import nart_tools.kestrel.utils.pod as pod
import nart_tools.kestrel.utils.scaffold as scaffold

import nart_tools.caffe.utils.graph as graph
import nart_tools.caffe.convert as convert
import nart_tools.caffe.count as count
import nart_tools.proto.caffe_pb2 as caffe_pb2

def generate_config(train_config, kestrel_config, anchor_config):
    with open(train_config) as f:
        train_cfg = yaml.load(f)

    kestrel_param = dict()

    # parse config parameters needed

    # net param
    assert 'net' in train_cfg, 'config file incomplete: lack net infomation'
    net_param = pod.parse_net_param(train_cfg['net'])
    assert 'backbone' in net_param and 'neck' in net_param and 'roi_head' in net_param and 'bbox_head' not in net_param
    kestrel_net_param = dict()
    kestrel_net_param['anchor_ratios'] = net_param['roi_head']['anchor_ratios']
    kestrel_net_param['anchor_scales'] = net_param['roi_head']['anchor_scales']
    kestrel_net_param['rpn_stride'] = net_param['neck']['out_strides']
    kestrel_net_param['anchors'] = pod.generate_anchor(
        anchor_config, kestrel_net_param['anchor_ratios'],
        kestrel_net_param['anchor_scales'], kestrel_net_param['rpn_stride'])
    kestrel_net_param['rpn_top_n'] = [net_param['roi_head']['post_nms_top_n']] * len(net_param['neck']['out_strides'])
    kestrel_net_param['aft_top_k'] = net_param['roi_head']['top_n_across_levels']
    kestrel_net_param['nms_thresh'] = net_param['roi_head']['nms_iou_thresh_across_levels']
    kestrel_net_param['with_background_class'] = net_param['roi_head']['with_background_class']

    kestrel_param.update(kestrel_net_param)
    # dataset param
    assert 'dataset' in train_cfg, 'config file incomplete: lack dataset'

    # process background class
    if kestrel_net_param['with_background_class']:
        train_cfg['dataset']['class_names'] = train_cfg['dataset']['class_names'][1:]

    if kestrel_config == '':
        kestrel_cfg = dict()
        kestrel_cfg['class'] = {name:{} for name in train_cfg['dataset']['class_names']}
    else:
        with open(kestrel_config) as f:
            kestrel_cfg = yaml.load(f)
    dataset_param = pod.parse_dataset_param(train_cfg['dataset'], kestrel_cfg['class'], 'thresh', 0)
    kestrel_param.update(dataset_param)
    kestrel_param['rgb_flag'] = True

    return kestrel_param


def is_score_branch(node):
    typ = node.content.type
    parent_typ = '' if len(node.prev) != 1 else node.prev[0].content.type
    return typ == 'Sigmoid' or typ == 'Softmax' or parent_typ == 'Sigmoid' or parent_typ == 'Softmax'

def process_net(prototxt, model, anchor_num, cls_num, input_h, input_w):
    # get net
    net, withBinFile  = graph.readNetStructure(args.prototxt,
                                         args.model)

    # update input dim
    scaffold.update_input_dim(net, 0, [1, 3, input_h, input_w])

    # merge bn
    net = scaffold.merge_bn(net)

    # process reshape
    pod.process_reshape(net, anchor_num, cls_num, anchor_precede=True)

    # get net info
    net_info = dict()
    net_graph = graph.gen_graph(net)

    assert len(net_graph.root) == 1
    net_info['data'] = net_graph.root[0].content.bottom[0]

    # select score and bbox output
    score = list()
    bbox = list()
    for leaf in net_graph.leaf:
        if is_score_branch(leaf):
            score.append(leaf.content.top[0])
        else:
            bbox.append(leaf.content.top[0])

    _, _, blob_shape = count.inferNet(net)

    score.sort(key = lambda x: blob_shape[x][3], reverse=True)
    bbox.sort(key = lambda x: blob_shape[x][3], reverse=True)

    net_info['output'] = list()
    for i in range(len(bbox)):
        net_info['output'].append([score[i], bbox[i]])

    return net, net_info

def generate_common_param(net_info, max_batch_size):
    common_param = dict()
    net_param = dict()
    net_param['net'] = net_info['packname']
    net_param['backend'] = net_info['backend']
    net_param['max_batch_size'] = max_batch_size
    net_param['input'] = {'data': net_info['data']}

    net_param['output'] = dict()
    rpn_blob_param = list()
    for i, pair in enumerate(net_info['output']):
        score_key = 'score' + str(i)
        bbox_key = 'bbox' + str(i)
        net_param['output'][score_key] = pair[0]
        net_param['output'][bbox_key] = pair[1]
        rpn_blob_param.append([score_key, bbox_key])

    common_param['net'] = net_param
    return common_param, rpn_blob_param


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description = 'convert model and config from pytorch to kestrel essos')
    parser.add_argument('prototxt', help='path to the prototxt', action=None)
    parser.add_argument('model', help='path to the model.bin')
    parser.add_argument('-v', '--version', type=str, default='1.0.0', help='version to meta.conf')
    parser.add_argument('-t', '--train_config', type=str, help='path to train config')
    parser.add_argument('-k', '--kestrel_config', type=str, help='path to kestrel config', default='')
    parser.add_argument('-a', '--anchor', type=str, help='path to anchor.json', default='')
    parser.add_argument('-n', '--name', type=str, default='None', help='compressed model name')
    parser.add_argument('-p', '--save_path', help='path to save model', default='.')
    parser.add_argument('-b', '--max_batch_size', type=int, help='max batch size', default=8)
    parser.add_argument('-s', '--serialize', action='store_true', help='serialize fp32 model', default=False)
    args = parser.parse_args()

    # check meta version format
    version = scaffold.check_version_format(args.version)

    kestrel_param = generate_config(args.train_config, args.kestrel_config, args.anchor)

    # process_net
    cls_num = len(kestrel_param['class']) + int(kestrel_param['with_background_class'])
    anchor_num = len(kestrel_param['anchor_ratios']) * len(kestrel_param['anchor_scales'])
    net, net_info = process_net(args.prototxt, args.model,
                                anchor_num, cls_num,
                                kestrel_param['short_scale'],
                                kestrel_param['long_scale'])

    net_info['packname'] = 'model'
    net_info['backend'] = 'kestrel_caffe'
    # save model
    model_path = scaffold.generate_model(net, args.save_path, net_info['packname'])

    # serialize
    if args.serialize:
        net_info['packname'] = 'engine.bin'
        net_info['backend'] = 'kestrel_mixnet'
        engine_path = os.path.join(args.save_path, net_info['packname'])
        scaffold.serialize(model_path, args.max_batch_size, engine_path)

    common_param, rpn_blob_param = generate_common_param(net_info, args.max_batch_size)
    kestrel_param['model_files'] = common_param
    kestrel_param['rpn_blobs'] = rpn_blob_param

    scaffold.generate_json_file(os.path.join(args.save_path, 'parameters.json'),kestrel_param)
    scaffold.generate_meta(args.save_path, args.name, 'essos', version, {'class': kestrel_param['class']})
    scaffold.compress_model(args.save_path, [net_info['packname']], args.name, version)
    # print(net_info)


