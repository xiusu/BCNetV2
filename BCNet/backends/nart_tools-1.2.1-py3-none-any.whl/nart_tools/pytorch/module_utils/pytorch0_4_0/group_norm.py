import torch
from torch.autograd import Function

class GroupNormForward(Function):

    @staticmethod
    def forward(ctx, input, num_groups, weight, bias, eps):
        return torch.group_norm(input, num_groups, weight, bias, eps)

    @staticmethod
    def symbolic(g, input, num_groups, weight, bias, eps):
        if weight is not None and bias is not None:
            return g.op("GroupNorm", input, weight, bias, num_groups_i=num_groups, eps_f=eps)
        else:
            return g.op("GroupNorm", input, num_groups_i=num_groups, eps_f=eps)

def forward(input, num_groups, weight=None, bias=None, eps=1e-5):
    return GroupNormForward.apply(input, num_groups, weight, bias, eps)