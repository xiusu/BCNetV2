from .layer import Layer

class PSROIPooling(Layer):

    def set_top(self):
        self.params.top.extend(self.node.output)

    def set_bottom(self):
        self.params.bottom.extend(self.node.input)

    def set_param(self):
        attributes = dict(zip([attr.name for attr in self.node.attribute], self.node.attribute))
        self.params.psroi_pooling_param.spatial_scale = attributes['spatial_scale'].f 
        self.params.psroi_pooling_param.output_dim = attributes['output_dim'].i 
        self.params.psroi_pooling_param.group_size = attributes['group_size'].i 

    def set_blobshape(self):
        self.network.blobshape[self.params.top[0]] = [
                                    self.network.blobshape[self.params.bottom[1]][0],
                                    self.params.psroi_pooling_param.output_dim,
                                    self.params.psroi_pooling_param.group_size,
                                    self.params.psroi_pooling_param.group_size]