def merge_lstmcell_nodes(model):
    '''
    Version specific for 1.0.x
    A sequence of lstmcell nodes with the same input blob 
    corresponds to one holistic LSTMUnit layer in caffe.
    This method merges the nodes into one node corresponding
    to that layer.
    ''' 
    nodes = model.graph.node[:]
    del model.graph.node[:]

    idx = 0
    while idx < len(nodes):
        node = nodes[idx]
        if node.op_type != 'LSTMCell':
            model.graph.node.extend([node])
            idx += 1
            continue
        while idx < len(nodes):
            idx += 1
            if idx >= len(nodes):
                break
            lstmcell_node = nodes[idx]
            if lstmcell_node.op_type != 'LSTMCell' \
            or node.input != lstmcell_node.input:
                break
            node.output.extend(lstmcell_node.output)
        model.graph.node.extend([node])