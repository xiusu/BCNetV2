#!/usr/bin/env python
# -*- coding: utf-8 -*-
import argparse
import yaml
import os
import json

import nart_tools.kestrel.utils.scaffold as scaffold

import nart_tools.proto.caffe_pb2 as caffe_pb2
import nart_tools.caffe.utils.graph as graph
import nart_tools.caffe.convert as convert

def generate_category_param(class_label):
    idx = 0
    class_param = dict()
    for category in class_label:
        category_dict = dict()
        category_dict['calculator'] = class_label[category].get('calculator', 'bypass')
        category_dict['feature_start'] = class_label[category].get('start', idx)
        category_dict['feature_end'] = class_label[category].get('end', idx + len(class_label[category]['labels']) - 1)
        category_dict['labels'] = class_label[category]['labels']
        class_param[category] = category_dict
        idx += len(class_label[category]['labels'])
    return class_param

def generate_parameter(path, packname, max_batch_size, net_info, cfg_params):
    param = dict()
    param['model_files'] = dict()
    net = dict()
    net['net'] = packname
    net['backend'] = net_info['backend']
    net['max_batch_size'] = max_batch_size
    net['input'] = {'data': net_info['data']}
    net['output'] = {'score': net_info['score']}
    param['model_files']['net'] = net
    param['input_h'] = net_info['input_h']
    param['input_w'] = net_info['input_w']
    param['pixel_means'] = cfg_params['pixel_means']
    param['pixel_stds'] = cfg_params['pixel_stds']
    param['is_rgb'] = cfg_params.get('is_rgb', True)
    param['type'] = cfg_params.get('type', 'UNKNOWN')
    param['save_all_label'] = cfg_params.get('save_all_label', True)
    scaffold.generate_json_file(os.path.join(path, 'parameters.json'), param)
    class_label = generate_category_param(cfg_params['class_label'])
    scaffold.generate_json_file(os.path.join(path, 'category_param.json'), class_label)


def generate(net, path, name, serialize, max_batch_size, cfg_params, version):
    packname = 'model'
    # generate model and save to path
    model_path = scaffold.generate_model(net, path, packname)

    net_info = dict()
    # serialize model
    if serialize:
        packname = 'engine.bin'
        engine_path = os.path.join(path, packname)
        scaffold.serialize(model_path, max_batch_size, engine_path)
        net_info['backend'] = 'kestrel_mixnet'
    else:
        net_info['backend'] = 'kestrel_caffe'

    # generate meta
    scaffold.generate_meta(path, args.name, 'classifier', version)

    # generate parameter

    # get necessary infomation
    net_graph = graph.gen_graph(net)
    # input and output blob
    assert len(net_graph.root) == 1 and len(net_graph.root[0].content.bottom) == 1
    net_info['data'] = net_graph.root[0].content.bottom[0]
    net_graph = graph.gen_graph(net)
    assert len(net_graph.leaf) == 1 and len(net_graph.leaf[0].content.top) == 1, 'Net has more than one output blob.'
    net_info['score'] = net_graph.leaf[0].content.top[0]

    # input shape
    assert len(net.input_dim) < 1 or len(net.input_shape) < 1
    assert len(net.input_dim) > 0 or len(net.input_shape) > 0
    if len(net.input_dim) > 0:
        assert len(net.input_dim) == 4
        net_info['input_h'] = net.input_dim[2]
        net_info['input_w'] = net.input_dim[3]
    if len(net.input_shape) > 0:
        assert len(net.input_shape) == 1
        assert len(net.input_shape[0].dim) == 4
        net_info['input_h'] = net.input_shape[0].dim[2]
        net_info['input_w'] = net.input_shape[0].dim[3]

    generate_parameter(path, packname, max_batch_size, net_info, cfg_params)

    # compress and save
    scaffold.compress_model(path, [packname, 'category_param.json'], name, version)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='convert caffe and param to kestrel classifier model')
    parser.add_argument('prototxt', help='path to the prototxt')
    parser.add_argument('model', help='path to the model.bin')
    parser.add_argument('-v', '--version', type=str, default='1.0.0', help='version to meta.conf')
    parser.add_argument('-c', '--config', type=str, required=True, help='config file for necessary infomation')
    parser.add_argument('-n', '--name', type=str, default='None', help='compressed model name')
    parser.add_argument('-p', '--path', type=str, default='.', help='path to save model')
    parser.add_argument('-s', '--serialize', action="store_true", help='serialize fp32 model')
    parser.add_argument('-b', '--max_batch_size', type=int, default=32, help='max_batch_size')

    args = parser.parse_args()

    # check meta version format
    version = scaffold.check_version_format(args.version)

    # load class
    with open(args.config) as f:
        cfg = yaml.load(f)

    # get net
    net, withBinFile = graph.readNetStructure(args.prototxt, args.model)

    # merge bn
    net = scaffold.merge_bn(net)

    # generate
    generate(net, args.path, args.name, args.serialize, args.max_batch_size, cfg, version)
