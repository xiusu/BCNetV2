import torch
import math
from torch.autograd import Function
from torch.nn import Parameter

class LSTMCellForward(Function):

    @staticmethod
    def forward(ctx, input, h, c, weight_ih, weight_hh, bias_ih, bias_hh):
        return torch.nn.backends.thnn.backend._LSTMCell(
            input, (h, c),
            weight_ih, weight_hh,
            bias_ih, bias_hh
        )

    @staticmethod
    def symbolic(g, input, h, c, weight_ih, weight_hh, bias_ih, bias_hh):
        return g.op("LSTMCell", input, h, c, 
            weight_ih, weight_hh, 
            bias_ih, bias_hh, 
            outputs=2, num_output_i=h.type().sizes()[1])

def lstm_cell(input, hx, weight_ih, weight_hh, bias_ih, bias_hh):
    return LSTMCellForward.apply(input, hx[0], hx[1], weight_ih, weight_hh, bias_ih, bias_hh)