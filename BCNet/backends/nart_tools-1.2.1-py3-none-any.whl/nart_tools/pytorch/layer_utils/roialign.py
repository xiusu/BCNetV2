from .layer import Layer

class ROIAlign(Layer):

    def set_top(self):
        self.params.top.extend(self.node.output)

    def set_bottom(self):
        self.params.bottom.extend(self.node.input)

    def set_param(self):
        attributes = dict(zip([attr.name for attr in self.node.attribute], self.node.attribute))
        self.params.roi_align_pooling_param.spatial_scale = attributes['spatial_scale'].f 
        self.params.roi_align_pooling_param.pooled_h = attributes['pooled_height'].i 
        self.params.roi_align_pooling_param.pooled_w = attributes['pooled_width'].i 

    def set_blobshape(self):
        self.network.blobshape[self.params.top[0]] = [
                                    self.network.blobshape[self.params.bottom[1]][0],
                                    self.network.blobshape[self.params.bottom[1]][1],
                                    self.params.roi_align_pooling_param.pooled_h,
                                    self.params.roi_align_pooling_param.pooled_w]