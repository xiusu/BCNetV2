import torch
from importlib import import_module
major, minor, patch = torch.__version__[:5].split('.')
package = 'nart_tools.pytorch.module_utils'
if major == '0' and minor == '4':
    module = import_module('.pytorch' + '_'.join((major, minor, patch)), package=package)
elif major == '0' and minor == '3':
    module = import_module('.pytorch' + '_'.join((major, minor)), package=package)
elif major == '1':
    module = import_module('.pytorch1', package=package)
else:
    raise NotImplementedError("Unsupported torch version " + torch.__version__)
convert_mode = module.convert_mode

__all__ = ['convert_mode']
