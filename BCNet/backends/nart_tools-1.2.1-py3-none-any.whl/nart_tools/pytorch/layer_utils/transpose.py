from .layer import Layer

class Transpose(Layer):

    def set_top(self):
        self.params.top.extend(self.node.output)

    def set_bottom(self):
        self.params.bottom.extend(self.node.input)

    def set_param(self):
        attributes = dict(zip([attr.name for attr in self.node.attribute], self.node.attribute))
        self.params.transpose_param.dim.extend(attributes['perm'].ints)

    def set_blobshape(self):
        bottom_shape = self.network.blobshape[self.params.bottom[0]]
        top_shape = bottom_shape[:] 
        for i, j in enumerate(self.params.transpose_param.dim):
            top_shape[i] = bottom_shape[j]
        self.network.blobshape[self.params.top[0]] = top_shape