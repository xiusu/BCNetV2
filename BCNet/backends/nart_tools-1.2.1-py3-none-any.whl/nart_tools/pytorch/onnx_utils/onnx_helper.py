import google.protobuf.message  # type: ignore
from .onnx_pb2 import ModelProto, TensorProto
from . import mapping 
import numpy as np

TENSOR_TYPE_TO_NP_TYPE = {
    TensorProto.FLOAT: np.dtype('float32'),
    TensorProto.UINT8: np.dtype('uint8'),
    TensorProto.INT8: np.dtype('int8'),
    TensorProto.UINT16: np.dtype('uint16'),
    TensorProto.INT16: np.dtype('int16'),
    TensorProto.INT32: np.dtype('int32'),
    TensorProto.INT64: np.dtype('int64'),
    TensorProto.BOOL: np.dtype('bool'),
    TensorProto.FLOAT16: np.dtype('float16'),
    TensorProto.DOUBLE: np.dtype('float64'),
    TensorProto.COMPLEX64: np.dtype('complex64'),
    TensorProto.COMPLEX128: np.dtype('complex128'),
    TensorProto.UINT32: np.dtype('uint32'),
    TensorProto.UINT64: np.dtype('uint64'),
}

TENSOR_TYPE_TO_STORAGE_TENSOR_TYPE = {
    TensorProto.FLOAT: TensorProto.FLOAT,
    TensorProto.UINT8: TensorProto.INT32,
    TensorProto.INT8: TensorProto.INT32,
    TensorProto.UINT16: TensorProto.INT32,
    TensorProto.INT16: TensorProto.INT32,
    TensorProto.INT32: TensorProto.INT32,
    TensorProto.INT64: TensorProto.INT64,
    TensorProto.BOOL: TensorProto.INT32,
    TensorProto.FLOAT16: TensorProto.UINT16,
    TensorProto.DOUBLE: TensorProto.DOUBLE,
    TensorProto.COMPLEX64: TensorProto.FLOAT,
    TensorProto.COMPLEX128: TensorProto.FLOAT,
    TensorProto.UINT32: TensorProto.UINT32,
    TensorProto.UINT64: TensorProto.UINT64,
    TensorProto.STRING: TensorProto.STRING,
}

STORAGE_TENSOR_TYPE_TO_FIELD = {
    TensorProto.FLOAT: 'float_data',
    TensorProto.INT32: 'int32_data',
    TensorProto.INT64: 'int64_data',
    TensorProto.UINT16: 'int32_data',
    TensorProto.DOUBLE: 'double_data',
    TensorProto.COMPLEX64: 'float_data',
    TensorProto.COMPLEX128: 'float_data',
    TensorProto.UINT32: 'uint64_data',
    TensorProto.UINT64: 'uint64_data',
    TensorProto.STRING: 'string_data',
    TensorProto.BOOL: 'int32_data',
}

def load(obj):
    '''
    Loads a binary protobuf that stores onnx model
    @params
    Takes a file-like object (has "read" function)
    or a string containing a file name
    @return ONNX ModelProto object
    '''
    if hasattr(obj, 'read') and callable(obj.read):
        s = obj.read()
    else:
        with open(obj, 'rb') as f:
            s = f.read()
    return load_from_string(s)

def load_from_string(s):
    '''
    Loads a binary string that stores onnx model
    @params
    Takes a string object containing protobuf
    @return ONNX ModelProto object
    '''
    model = ModelProto()
    decoded = model.ParseFromString(s)
    # in python implementation ParseFromString returns None
    if decoded is not None and decoded != len(s):
        raise google.protobuf.message.DecodeError(
            "Protobuf decoding consumed too few bytes: {} out of {}".format(
                decoded, len(s)))
    return model

def combine_pairs_to_complex(fa):  # type: (Sequence[int]) -> Sequence[np.complex64]
    return [complex(fa[i * 2], fa[i * 2 + 1]) for i in range(len(fa) // 2)]


def to_array(tensor):  # type: (TensorProto) -> np.ndarray[Any]
    """Converts a tensor def object to a numpy array.
    Inputs:
        tensor: a TensorProto object.
    Returns:
        arr: the converted array.
    """
    if tensor.HasField("segment"):
        raise ValueError(
            "Currently not supporting loading segments.")
    if tensor.data_type == TensorProto.UNDEFINED:
        raise ValueError("The data type is not defined.")
    if tensor.data_type == TensorProto.STRING:
        raise ValueError("Tensor data type STRING is not supported.")

    tensor_dtype = tensor.data_type
    np_dtype = mapping.TENSOR_TYPE_TO_NP_TYPE[tensor_dtype]
    storage_type = mapping.TENSOR_TYPE_TO_STORAGE_TENSOR_TYPE[tensor_dtype]
    storage_np_dtype = mapping.TENSOR_TYPE_TO_NP_TYPE[storage_type]
    storage_field = mapping.STORAGE_TENSOR_TYPE_TO_FIELD[storage_type]
    dims = tensor.dims

    if tensor.HasField("raw_data"):
        # Raw_bytes support: using frombuffer.
        return np.frombuffer(
            tensor.raw_data,
            dtype=np_dtype).reshape(dims)
    else:
        data = getattr(tensor, storage_field),  # type: Sequence[np.complex64]
        if (tensor_dtype == TensorProto.COMPLEX64 or
                tensor_dtype == TensorProto.COMPLEX128):
            data = combine_pairs_to_complex(data)
        return (
            np.asarray(
                data,
                dtype=storage_np_dtype)
            .astype(np_dtype)
            .reshape(dims)
        )


def from_array(arr, name=None):  # type: (np.ndarray[Any], Optional[Text]) -> TensorProto
    """Converts a numpy array to a tensor def.
    Inputs:
        arr: a numpy array.
        name: (optional) the name of the tensor.
    Returns:
        tensor_def: the converted tensor def.
    """
    tensor = TensorProto()
    tensor.dims.extend(arr.shape)
    if name:
        tensor.name = name

    if arr.dtype == np.object:
        # Special care for strings.
        raise NotImplementedError("Need to properly implement string.")
    # For numerical types, directly use numpy raw bytes.
    try:
        dtype = mapping.NP_TYPE_TO_TENSOR_TYPE[arr.dtype]
    except KeyError:
        raise RuntimeError(
            "Numpy data type not understood yet: {}".format(str(arr.dtype)))
    tensor.data_type = dtype
    tensor.raw_data = arr.tobytes()  # note: tobytes() is only after 1.9.

    return tensor