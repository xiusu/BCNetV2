#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse
import yaml
import json
import nart_tools.caffe.utils.graph as graph
import nart_tools.kestrel.utils.net_transform as transform
from nart_tools.kestrel.utils.anchor_helper import get_anchors_over_grid

def generate_class_param(class_name, class_param_in, thresh_name, conf_thresh):
    class_param = list()
    for i, cls in enumerate(class_name):
        assert cls in class_param_in, 'lack kestrel {} class config'.format(cls)
        cls_cfg = {
            thresh_name: class_param_in[cls].get('confidence_thresh', conf_thresh),
            'id': class_param_in[cls].get('id', i),
            'label': cls,
            'filter_h': class_param_in[cls].get('filter_h', 0),
            'filter_w': class_param_in[cls].get('filter_w', 0)
        }
        class_param.append(cls_cfg)
    return class_param


def parse_dataset_param(dataset_cfg, class_cfg, thresh_name, conf_thresh):
    # class_name
    assert 'class_names' in dataset_cfg, 'You must provide class names for kestrel sdk'
    class_name = dataset_cfg['class_names']
    class_param = generate_class_param(class_name, class_cfg, thresh_name, conf_thresh)

    # has_keypoint has_mask
    has_keypoint = dataset_cfg.get('has_keypoint', None)
    has_mask = dataset_cfg.get('has_mask', None)
    # scales
    assert 'scales' in dataset_cfg, 'You must provide scales for resize'
    assert 'max_size' in dataset_cfg, 'You must provide max_size for resize'
    short_scale = max(dataset_cfg['scales'])
    long_scale = dataset_cfg['max_size']
    # mean std
    assert 'pixel_mean' in dataset_cfg, 'You must provide pixel mean for normalize'
    assert 'pixel_std' in dataset_cfg, 'You must provide pixel std for normalize'
    pixel_means = dataset_cfg['pixel_mean']
    pixel_stds = dataset_cfg['pixel_std']

    dataset_param = dict()
    dataset_param['class'] = class_param
    dataset_param['short_scale'] = short_scale
    dataset_param['long_scale'] = long_scale
    dataset_param['pixel_means'] = [i * 255 for i in pixel_means]
    dataset_param['pixel_stds'] = [i * 255 for i in pixel_stds]

    return dataset_param #, class_meta


def parse_head_param(head_cfg):
    head_name = head_cfg['name']
    head_type = head_cfg['type']
    head_param = dict()
    if 'roi' in head_name:
        # parse roi param
        # unused
        num_classes = head_cfg['kwargs']['num_classes']
        roi_min_size = head_cfg['kwargs']['cfg']['roi_min_size']
        pre_nms_score_thresh = head_cfg['kwargs']['cfg']['test']['pre_nms_score_thresh'] if 'NaiveRPN' in head_type else head_cfg['kwargs']['cfg']['pre_nms_score_thresh']

        with_background_class = True
        if 'RetinaSubNet' in head_type:
            nms_iou_thresh_across_levels = head_cfg['kwargs']['cfg']['nms_iou_thresh_across_levels']
            top_n_across_levels = head_cfg['kwargs']['cfg']['test']['top_n_across_levels']
            if head_cfg['kwargs']['cfg']['focal_loss']['type'] == 'sigmoid':
                with_background_class = False
            head_param['with_background_class'] = with_background_class
            head_param['top_n_across_levels'] = top_n_across_levels
            head_param['nms_iou_thresh_across_levels'] = nms_iou_thresh_across_levels
        else:
            allowed_border = head_cfg['kwargs']['cfg']['allowed_border']

        # used
        pre_nms_top_n = head_cfg['kwargs']['cfg']['test']['pre_nms_top_n']
        post_nms_top_n = head_cfg['kwargs']['cfg']['test']['post_nms_top_n']
        nms_iou_thresh = head_cfg['kwargs']['cfg']['nms_iou_thresh']
        anchor_ratios = head_cfg['kwargs']['cfg']['anchor_ratios']
        anchor_scales = head_cfg['kwargs']['cfg']['anchor_scales']
        head_param['pre_nms_top_n'] = pre_nms_top_n
        head_param['post_nms_top_n'] = post_nms_top_n
        head_param['nms_iou_thresh'] = nms_iou_thresh
        head_param['anchor_ratios'] = anchor_ratios
        head_param['anchor_scales'] = anchor_scales

    elif 'bbox' in head_name:
        num_classes = head_cfg['kwargs']['num_classes']
        bbox_normalize_means = head_cfg['kwargs']['cfg']['bbox_normalize_means']
        bbox_normalize_stds = head_cfg['kwargs']['cfg']['bbox_normalize_stds']
        top_n = head_cfg['kwargs']['cfg']['test']['top_n']

        # used
        nms_iou_thresh = head_cfg['kwargs']['cfg']['test']['nms_iou_thresh']
        bbox_score_thresh = head_cfg['kwargs']['cfg']['test']['bbox_score_thresh']

        head_param['nms_iou_thresh'] = nms_iou_thresh
        head_param['bbox_score_thresh'] = bbox_score_thresh
    elif 'keyp' in head_name:
        num_keypoints = head_cfg['kwargs']['num_keypoints']
        head_param['num_keypoints'] = num_keypoints
    return head_param


def parse_net_param(net_cfg):
    net_param = dict()
    for subnet in net_cfg:
        mname = subnet['name']
        mtype = subnet['type']
        kwargs = subnet['kwargs']
        if mname == 'backbone':
            net_param[mname] = {'out_strides': subnet['kwargs']['out_strides']}
        elif mname == 'neck':
            # get stride
            net_param[mname] = {'out_strides': subnet['kwargs']['out_strides']}
        elif 'head' in mname:
            head_param = parse_head_param(subnet)
            net_param[mname] = head_param

    return net_param

def process_reshape(net, anchor_num, cls_num, anchor_precede=True):
    net_graph = graph.gen_graph(net)
    for node in net_graph.nodes():
        if node.content.type == 'Reshape':
            if (node.content.reshape_param.shape.dim == [0] * 4
                or len(node.succ) == 0):
                # remove useless reshape
                transform.remove_layer(net, node)
            elif len(node.succ) == 1 and 'Softmax' == node.succ[0].content.type:
                # update reshape dim
                node.content.reshape_param.shape.ClearField('dim')
                node.content.reshape_param.shape.dim.extend([0, anchor_num, cls_num, -1])
                # transpose to shape [batch, cls, anchor, h], ensure succeeding softmax can be done at axis=1
                trans_layer = transform.add_transpose(net, net_graph, node.content, 'anchor_cls', [0, 2, 1, 3])
                print('replace reshape layer: {} with (reshape layer: {} + transpose layer: {})'.format(node.content.name, node.content.name, trans_layer.name))
                if anchor_precede:
                    # for retina: transpose to shape [batch, anchor, cls, h * w], ensure anchor precede
                    assert len(node.succ) == 1
                    trans_layer = transform.add_transpose(net, net_graph, node.succ[0].content, 'anchor_cls', [0, 2, 1, 3])
                    print('restore dim order to anchor precede with (transpose layer: {})'.format(trans_layer.name))
    return net

def generate_anchor(anchor_file, ratios, scales, strides):
    # anchor param
    anchors = list()
    if anchor_file == '':
        print('use default anchor generate method')
        for stride in strides:
            anchors.append(get_anchors_over_grid(ratios, scales, stride).tolist())
    else:
        print('load config in anchors.json')
        with open(anchor_file) as f:
            anchor_param = json.load(f)
        for stride in strides:
            anchors.append(anchor_param['anchors'][str(stride)])
    return anchors

def generate_config(train_config, kestrel_config):
    with open(train_config) as f:
        train_cfg = yaml.load(f)
    with open(kestrel_config) as f:
        kestrel_cfg = yaml.load(f)
    # print(cfg)

    kestrel_param = dict()

    # parse config parameters needed

    # net param
    assert 'net' in train_cfg, 'config file incomplete: lack net infomation'
    net_param = parse_net_param(train_cfg['net'])
    kestrel_param.update(net_param)

    # dataset param
    assert 'dataset' in train_cfg, 'config file incomplete: lack dataset'
    dataset_param = parse_dataset_param(train_cfg['dataset'], kestrel_cfg['class'])
    kestrel_param.update(dataset_param)

    # algorithm_type
    # algorithm_type = ['faster-rcnn', 'faster-rcnn-fpn', 'rfcn', 'retina', 'mask-rcnn']

    return kestrel_param


def main():
    args = parser.parse_args()
    print(args._get_kwargs())
    kestrel_param = generate_config(args.train_config, args.kestrel_config)
    print(json.dumps(kestrel_param, indent=4))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description = 'convert model and config from pytorch to kestrel')
    parser.add_argument("prototxt", help="rel.prototxt", action=None)
    parser.add_argument("model", nargs="?", help="model.bin", default="model.bin")
    parser.add_argument("-t", "--train-config", nargs="?", help="train_config.yaml", default="")
    parser.add_argument("-k", "--kestrel-config", nargs="?", help="kestrel_config.yaml", default="")
    parser.add_argument("-s", "--save_path", help="", default="")

    main()
